#include <stdio.h>
#include <stdlib.h>

int s21_strlen(const char *str) {
    int c = 0;
    while (str[c] != '\0') {
        c++;
    }
    return c;
}

int s21_strcmp(char *str1, char *str2) {
    for (; *str1 && *str1 == *str2; str1++, str2++) {
        continue;
    }
    return *str1 - *str2;
}

char *s21_strcpy(char *cop, char const *target) {
    char *ptr = cop;
    while (*target != '\0') {
        *cop = *target;
        cop++;
        target++;
    }
    *cop = '\0';
    return ptr;
}

void s21_strcat(char *str1, const char *str2) {
    while (*str1)
        str1++;
    while (*str2) {
        *str1 = *str2;
        str1++;
        str2++;
    }
    *str1 = '\0';
}

char* s21_strchr(char *str, char search) {
    for (int i = 0; i < s21_strlen(str); i++) {
        if (str[i] == search)
            return str;
    }
    return NULL;
}

char *s21_strstr(char *str, char *substr) {
    const char *a = str, *b = substr;
    while (1) {
        if ( !*b ) return (char *) str;
        if ( !*a ) return NULL;
        if (*a++ != *b++) {
            a = ++str;
            b = substr;
        }
    }
}
