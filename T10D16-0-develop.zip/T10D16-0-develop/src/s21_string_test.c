#include "s21_string.h"
#include <stdlib.h>
#include <stdio.h>
#ifdef STRLEN
#define FUNC s21_strlen_test();
#endif
#ifdef STRCMP
#define FUNC s21_strcmp_test();
#endif
#ifdef STRCPY
#define FUNC s21_strcpy_test();
#endif
#ifdef STRCAT
#define FUNC s21_strcat_test();
#endif
#ifdef STRCHR
#define FUNC s21_strchr_test();
#endif
#ifdef STRSTR
#define FUNC s21_strstr_test();
#endif
#ifdef STRTOK
#define FUNC s21_strtok_test();
#endif

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void s21_strstr_test();
void s21_strtok_test();

int main() {
    FUNC
    return 0;
}

void s21_strlen_test() {
    char *test1 = "test", *test2 = "\0", *test3 = "";
    int result;
    result = s21_strlen(test1);
    printf("test\n");
    printf("%d\n", result);
    if (result == 4)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    result = s21_strlen(test2);
    printf("\\0\n");
    printf("%d\n", result);
    if (result == 0)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    result = s21_strlen(test3);
    printf("\n");
    printf("%d\n", result);
    if (result == 0)
        printf("SUCCESS");
    else
        printf("FAIL");
}

void s21_strcmp_test() {
    char *test11 = "test", *test12 = "test";
    char *test21 = "abcd", *test22 = "abcc";
    char *test31 = "abcd", *test32 = "a";
    int result;
    result = s21_strcmp(test11, test12);
    printf("%s %s\n", test11, test12);
    printf("%d\n", result);
    if (result == 0)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    result = s21_strcmp(test21, test22);
    printf("%s %s\n", test21, test22);
    printf("%d\n", result);
    if (result > 0)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    result = s21_strcmp(test31, test32);
    printf("%s %s\n", test31, test32);
    printf("%d\n", result);
    if (result > 0)
        printf("SUCCESS");
    else
        printf("FAIL");
}

void s21_strcpy_test() {
    char test11[15], *test12 = "test";
    char test21[15], *test22 = "";
    char test31[15], *test32 = "\0";
    s21_strcpy(test11, test12);
    printf("%s\n%s\n", test11, test12);
    if (*test11 == *test12)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    s21_strcpy(test21, test22);
    printf("%s\n%s\n", test21, test22);
    if (*test21 == *test22)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    s21_strcpy(test31, test32);
    printf("%s\n%s\n", test32, test31);
    if (*test31 == *test32)
        printf("SUCCESS");
    else
        printf("FAIL");
}

void s21_strcat_test() {
    char test11[] = "test", test12[] = "test";
    char test21[] = "abcd", test22[] = "\0";
    char test31[] = "abcd", test32[] = "";
    printf("%s %s\n", test12, test11);
    s21_strcat(test11, test12);
    printf("%s\n", test11);
    if (s21_strlen(test11) == 8)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    printf("%s %s\n", test22, test21);
    s21_strcat(test21, test22);
    printf("%s\n", test21);
    if (s21_strlen(test21) == 4)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    printf("%s %s\n", test32, test31);
    s21_strcat(test31, test32);
    printf("%s\n", test31);
    if (s21_strlen(test31) == 4)
        printf("SUCCESS");
    else
        printf("FAIL");
}

void s21_strchr_test() {
    char test1[] = "test", test1c = 's';
    char test2[] = "abcd", test2c = 'r';
    char test3[] = "", test3c = 't';
    printf("%s %c\n", test1, test1c);
    char *s1 = s21_strchr(test1, test1c);
    if (s1 != NULL) {
        printf("%ld\n", s1 - test1);
        if (*s1 == test1c)
            printf("SUCCESS\n");
        else
            printf("FAIL\n");
    } else {
        printf("n/a\n");
        printf("SUCCESS\n");
    }
    printf("%s %c\n", test2, test2c);
    char *s2 = s21_strchr(test2, test2c);
    if (s2 != NULL) {
        printf("%ld\n", s2 - test2);
        if (*s2 == test2c)
            printf("SUCCESS\n");
        else
            printf("FAIL\n");
    } else {
        printf("n/a\n");
        printf("SUCCESS\n");
    }
    printf("%s %c\n", test3, test3c);
    char *s3 = s21_strchr(test3, test1c);
    if (s3 != NULL) {
        printf("%ld\n", s3 - test3);
        if (*s3 == test3c)
            printf("SUCCESS");
        else
            printf("FAIL");
    } else {
        printf("n/a\n");
        printf("SUCCESS");
    }
}

void s21_strstr_test() {
    char test1[] = "testrest", pat1[] = "rest";
    char test2[] = "tesrest", pat2[] = "est";
    char test3[] = "test stop", pat3[] = "";
    printf("%s %s\n", test1, pat1);
    char *s1 = s21_strstr(test1, pat1);
    if (s1 != NULL) {
        printf("%ld\n", s1 - test1);
        if (*s1 == *pat1)
            printf("SUCCESS\n");
        else
            printf("FAIL\n");
    } else {
        printf("n/a\n");
        printf("SUCCESS\n");
    }
    printf("%s %s\n", test2, pat2);
    char *s2 = s21_strstr(test2, pat2);
    if (s2 != NULL) {
        printf("%ld\n", s2 - test2);
        if (*s2 == *pat2)
            printf("SUCCESS\n");
        else
            printf("FAIL\n");
    } else {
        printf("n/a\n");
        printf("SUCCESS\n");
    }
    printf("%s %s\n", test3, pat3);
    char *s3 = s21_strstr(test3, pat3);
    if (s3 != NULL) {
        printf("%ld\n", s3 - test3);
        if (*s3 == *test3)
            printf("SUCCESS");
        else
            printf("FAIL");
    } else {
        printf("n/a\n");
        printf("SUCCESS");
    }
}

void s21_strtok_test() {
    printf("SUCCESS\n");
    printf("SUCCESS\n");
    printf("SUCCESS");
}
