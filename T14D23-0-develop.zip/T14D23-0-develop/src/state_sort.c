#include <stdio.h>
#include <stdlib.h>

struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

struct my_struct read_record_from_file(FILE *pfile, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);
    rewind(pfile);
    return record;
}

void write_record_in_file(FILE *pfile,
                          const struct my_struct *record_to_write, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    fwrite(record_to_write, sizeof(struct my_struct), 1, pfile);
    fflush(pfile);
    rewind(pfile);
}

void swap_records_in_file(FILE *pfile, int record_index1, int record_index2) {
    struct my_struct record1 = read_record_from_file(pfile, record_index1);
    struct my_struct record2 = read_record_from_file(pfile, record_index2);
    write_record_in_file(pfile, &record1, record_index2);
    write_record_in_file(pfile, &record2, record_index1);
}

int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);
    size = ftell(pfile);
    rewind(pfile);
    return size;
}

int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}

int compare(struct my_struct elem1, struct my_struct elem2) {
    int check = 0;
    if (elem1.year > elem2.year) {
        check = 1;
    } else if (elem1.year == elem2.year) {
        if (elem1.month > elem2.month) {
            check = 1;
        } else if (elem1.month == elem2.month) {
            if (elem1.day > elem2.day) {
                check = 1;
            } else if (elem1.day == elem2.day) {
                if (elem1.hour > elem2.hour) {
                    check = 1;
                } else if (elem1.hour == elem2.hour) {
                    if (elem1.minute > elem2.minute) {
                        check = 1;
                    } else if (elem1.minute == elem2.minute) {
                        if (elem1.second > elem2.second) {
                            check = 1;
                        }
                    }
                }
            }
        }
    }
    return check;
}

void sort(FILE *file) {
    int n = get_records_count_in_file(file);
    struct my_struct elem1;
    struct my_struct elem2;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n; j++) {
            elem1 = read_record_from_file(file, j);
            elem2 = read_record_from_file(file, j + 1);
            if (compare(elem1, elem2))
                swap_records_in_file(file, j, j + 1);
        }
    }
}

int input(struct my_struct *d) {
    int y, m, day, h, min, sec, st, code, check = 0;
    if (scanf("%d %d %d %d %d %d %d %d", &y,
              &m, &day, &h, &min, &sec, &st, &code)
        && y >= 0 && 1 <= m && m <= 12
        && 1 <= day && day <= 31 && 0 <= h && h <= 24
        && 0 <= m && m <= 60 && 0 <= sec
        && sec <= 60 && (st == 1 || st == 0)) {
        check = 1;
    }
    d->year = y;
    d->month = m;
    d->day = day;
    d->hour = h;
    d->minute = min;
    d->second = sec;
    d->status = st;
    d->code = code;
    return check;
}

void output(FILE *f) {
    int i, n = get_records_count_in_file(f);
    for (i = 0; i < n - 1; i++) {
        struct my_struct record = read_record_from_file(f, i);
        printf("%d %d %d %d %d %d %d %d\n", record.year,
               record.month, record.day, record.hour,
               record.minute, record.second, record.status, record.code);
    }
    struct my_struct record = read_record_from_file(f, i);
    printf("%d %d %d %d %d %d %d %d", record.year, record.month,
           record.day, record.hour,
           record.minute, record.second, record.status, record.code);
}

int main() {
    FILE *f;
    char filename[100];
    int but;
    struct my_struct elem;
    if (scanf("%s", filename)) {
        if ((f = fopen(filename, "rb+"))) {
            if (scanf("%d", &but)) {
                switch (but) {
                    case 0:
                        output(f);
                        break;
                    case 1:
                        sort(f);
                        output(f);
                        break;
                    case 2:
                        if (input(&elem)) {
                            int n = get_records_count_in_file(f);
                            write_record_in_file(f, &elem, n);
                            sort(f);
                            output(f);
                        } else {
                            printf("n/a");
                        }
                        break;
                    default:
                        printf("n/a");
                        break;
                }
            } else {
                printf("n/a");
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    fclose(f);
    return 0;
}
