#include <stdio.h>
#include <stdlib.h>

struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

struct my_struct read_record_from_file(FILE *pfile, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);
    rewind(pfile);
    return record;
}

void write_record_in_file(FILE *pfile,
                          const struct my_struct *record_to_write, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    fwrite(record_to_write, sizeof(struct my_struct), 1, pfile);
    fflush(pfile);
    rewind(pfile);
}

int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);
    size = ftell(pfile);
    rewind(pfile);
    return size;
}

int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}

int scan_date(int *day, int *month, int *year) {
  int d, m, y;
  int res = 0;
  if (scanf("%d.%d.%d", &d, &m, &y) == 3 && d > 0
      && d <= 31 && m > 0 && m <= 12 && y >= 0) {
    *day = d;
    *month = m;
    *year = y;
    res = 1;
  }
  return res;
}

int search(FILE *f) {
    int n = get_records_count_in_file(f), d, m, y;
    struct my_struct elem;
    if (scan_date(&d, &m, &y)) {
        for (int i = 0; i < n; i++) {
            elem = read_record_from_file(f, i);
            if (elem.year == y && elem.month == m && elem.day == d)
                return elem.code;
        }
    }
    return -1;
}

int main() {
    FILE *f;
    char filename[100];
    int sch;
    if (scanf("%s", filename)) {
        if ((f = fopen(filename, "r"))) {
            sch = search(f);
            if (sch != -1)
                printf("%d", sch);
            else
                printf("n/a");
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    fclose(f);
    return 0;
}
