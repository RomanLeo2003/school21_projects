#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

struct my_struct read_record_from_file(FILE *pfile, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);
    rewind(pfile);
    return record;
}

void write_record_in_file(FILE *pfile,
                          const struct my_struct *record_to_write, int index) {
    int offset = index * sizeof(struct my_struct);
    fseek(pfile, offset, SEEK_SET);
    fwrite(record_to_write, sizeof(struct my_struct), 1, pfile);
    fflush(pfile);
    rewind(pfile);
}

void swap_records_in_file(FILE *pfile, int record_index1, int record_index2) {
    struct my_struct record1 = read_record_from_file(pfile, record_index1);
    struct my_struct record2 = read_record_from_file(pfile, record_index2);
    write_record_in_file(pfile, &record1, record_index2);
    write_record_in_file(pfile, &record2, record_index1);
}

int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);
    size = ftell(pfile);
    rewind(pfile);
    return size;
}

int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}

int scan_date(int *day, int *month, int *year) {
    int d, m, y;
    int res = 0;
    if (scanf("%d.%d.%d", &d, &m, &y) == 3 && d > 0
        && d <= 31 && m > 0 && m <= 12 && y >= 0) {
        *day = d;
        *month = m;
        *year = y;
        res = 1;
    }
    return res;
}

int compare(struct my_struct elem1, struct my_struct elem2) {
    int check = 0;
    if (elem1.year > elem2.year) {
        check = 1;
    } else if (elem1.year == elem2.year) {
        if (elem1.month > elem2.month) {
            check = 1;
        } else if (elem1.month == elem2.month) {
            if (elem1.day > elem2.day) {
                check = 1;
            } else if (elem1.day == elem2.day) {
                if (elem1.hour > elem2.hour) {
                    check = 1;
                } else if (elem1.hour == elem2.hour) {
                    if (elem1.minute > elem2.minute) {
                        check = 1;
                    } else if (elem1.minute == elem2.minute) {
                        if (elem1.second > elem2.second) {
                            check = 1;
                        }
                    }
                }
            }
        }
    }
    return check;
}

void sort(FILE *file) {
    int n = get_records_count_in_file(file);
    struct my_struct elem1;
    struct my_struct elem2;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0;  j < n; j++) {
            elem1 = read_record_from_file(file, j);
            elem2 = read_record_from_file(file, j + 1);
            if (compare(elem1, elem2))
                swap_records_in_file(file, j, j + 1);
        }
    }
}

void output(FILE *f) {
    int i, n = get_records_count_in_file(f);
    for (i = 0; i < n - 1; i++) {
        struct my_struct record = read_record_from_file(f, i);
        printf("%d %d %d %d %d %d %d %d\n", record.year,
               record.month, record.day, record.hour,
               record.minute, record.second, record.status, record.code);
    }
    struct my_struct record = read_record_from_file(f, i);
    printf("%d %d %d %d %d %d %d %d", record.year,
           record.month, record.day, record.hour,
           record.minute, record.second, record.status, record.code);
}

FILE *rem(FILE *f, char *filename, int y1, int m1,
         int d1, int y2, int m2, int d2) {
    char new_file[200];
    strcpy(new_file, filename);
    strcat(new_file, "c");
    FILE *fp = fopen(new_file, "wb+");
    int n = get_records_count_in_file(f), c = 0;
    struct my_struct elem;
    for (int i = 0; i < n; i++) {
        elem = read_record_from_file(f, i);
        if ((elem.year > y2) || (elem.year < y1)) {
            write_record_in_file(fp, &elem, i - c);
        } else if (elem.year == y2 && elem.month > m2) {
            write_record_in_file(fp, &elem, i - c);
        } else if (elem.year == y2 && elem.month == m2 && elem.day > d2) {
            write_record_in_file(fp, &elem, i - c);
        } else if (elem.year == y1 && elem.month < m1) {
            write_record_in_file(fp, &elem, i - c);
        } else if (elem.year == y1 && elem.month == m1 && elem.day < d1) {
            write_record_in_file(fp, &elem, i - c);
        } else {
            c++;
        }
    }
    remove(filename);
    rename(new_file, filename);
    return fp;
}

int main() {
    FILE *f, *new_f;
    char filename[100];
    int y1, y2, m1, m2, d1, d2;
    if (scanf("%s", filename)) {
        if ((f = fopen(filename, "rb+"))) {
            sort(f);
            if (scan_date(&d1, &m1, &y1) && scan_date(&d2, &m2, &y2)) {
                new_f = rem(f, filename, y1, m1, d1, y2, m2, d2);
                output(new_f);
            } else {
                printf("n/a");
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    fclose(f);
    return 0;
}

