#include <stdio.h>
#include <stdlib.h>
#define NMAX 100

int alloc1(int ***a, int n, int m);
int alloc2(int ***a, int n, int m);
int alloc3(int ***a, int n, int m);
int stat(int a[][NMAX], int n, int m);
void output(int **a, int n, int m);
void stat_output(int a[][NMAX], int n, int m);


int main() {
    int n, m, k, **arr, st[NMAX][NMAX];
    if (scanf("%d", &k) &&
        (k == 1 || k == 2
         || k == 3 || k == 4)) {
        if (scanf("%d%d", &n, &m) == 2) {
            if (k == 2) {
                if (alloc1(&arr, n, m)) {
                    output(arr, n, m);
                    free(arr);
                } else {
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 3) {
                if (alloc2(&arr, n, m)) {
                    output(arr, n, m);
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                } else {
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 4) {
                if (alloc3(&arr, n, m)) {
                    output(arr, n, m);
                    free(arr);
                } else {
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 1) {
                if (stat(st, n, m)) {
                    stat_output(st, n, m);
                } else {
                    printf("n/a");
                }
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int stat(int a[][NMAX], int n, int m) {
    int a_el;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                a[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc1(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * m * sizeof(int) + n * sizeof(int*));
    int *ptr = (int*)(*a + n);
    for (int i = 0; i < n; i++)
        (*a)[i] = ptr + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc2(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < m; i++)
        (*a)[i] = (int*)malloc(m * sizeof(int*));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc3(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * sizeof(int*));
    int *values = (int*)malloc(m * n * sizeof(int));
    for (int i = 0; i < n; i++)
        (*a)[i] = values + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el)) {
                (*a)[i][j] = a_el;
            } else {
                free(values);
                return 0;
            }
        }
    }
    free(values);
    return 1;
}


void output(int **a, int n, int m) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d", a[i][j]);
}

void stat_output(int a[][NMAX], int n, int m) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d", a[i][j]);
}
