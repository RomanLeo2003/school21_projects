#include <stdio.h>
#include <stdlib.h>

int input(int **a, int n);
void output(int *a, int n);
void quick_sort(int *a, int n);

int main() {
    int N, *arr;
    if (scanf("%d", &N)) {
        if (input(&arr, N)) {
            quick_sort(arr, N);
            output(arr, N);
            free(arr);
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int **a, int n) {
    int a_el;
    (*a) = (int*) malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a_el)) {
            (*a)[i] = a_el;
        } else {
            free(*a);
            return 0;
        }
    }
    return 1;
}

void quick_sort(int *a, int n) {
    int i = 0;
    int j = n - 1;
    int mid = a[n / 2];
    do {
        while (a[i] < mid)
            i++;
        while (a[j] > mid)
            j--;
        if (i <= j) {
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            i++;
            j--;
        }
    } while (i <= j);

    if (j > 0) {
        quick_sort(a, j + 1);
    }
    if (i < n) {
        quick_sort(&a[i], n - i);
    }
}

void output(int *a, int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}
