#include <stdio.h>
#include <stdlib.h>

int alloc1(int ***a, int n, int m);
int alloc2(int ***a, int n, int m);
int alloc3(int ***a, int n, int m);
void summa(int **a, int **sums, int n, int m);
void sort_matrix(int ***a, int n, int m, int *sums);
void swap(int ***a, int k, int n, int m);
void output(int **a, int n, int m);

int main() {
    int n, m, k, **arr, *sums;
    if (scanf("%d", &k) &&
        (k == 1 || k == 2 || k == 3)) {
        if (scanf("%d%d", &n, &m) == 2) {
            if (k == 1) {
                if (alloc1(&arr, n, m)) {
                    summa(arr, &sums, n, m);
                    sort_matrix(&arr, n, m, sums);
                    output(arr, n, m);
                    free(arr);
                    free(sums);
                } else {
                    free(arr);
                    free(sums);
                    printf("n/a");
                }
            } else if (k == 2) {
                if (alloc2(&arr, n, m)) {
                    summa(arr, &sums, n, m);
                    sort_matrix(&arr, n, m, sums);
                    output(arr, n, m);
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                    free(sums);
                } else {
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                    free(sums);
                    printf("n/a");
                }
            } else if (k == 3) {
                if (alloc3(&arr, n, m)) {
                    summa(arr, &sums, n, m);
                    sort_matrix(&arr, n, m, sums);
                    output(arr, n, m);
                    free(arr);
                    free(sums);
                } else {
                    free(arr);
                    free(sums);
                    printf("n/a");
                }
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int alloc1(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * m * sizeof(int) + n * sizeof(int*));
    int *ptr = (int*)(*a + n);
    for (int i = 0; i < n; i++)
        (*a)[i] = ptr + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc2(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < m; i++)
        (*a)[i] = (int*)malloc(m * sizeof(int*));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc3(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * sizeof(int*));
    int *values = (int*)malloc(m * n * sizeof(int));
    for (int i = 0; i < n; i++)
        (*a)[i] = values + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el)) {
                (*a)[i][j] = a_el;
            } else {
                free(values);
                return 0;
            }
        }
    }
    free(values);
    return 1;
}

void summa(int **a, int **sums, int n, int m) {
    *sums = (int*)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        int sum = 0;
        for (int j = 0; j < m; j++) {
            sum += a[i][j];
        }
        (*sums)[i] = sum;
    }
}

void swap_str(int ***a, int k, int n, int m) {
    int *cur = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n - 1; i++) {
        if (i == k) {
            for (int j = 0; j < m; j++) {
                cur[j] = (*a)[i][j];
                (*a)[i][j] = (*a)[i + 1][j];
                (*a)[i + 1][j] = cur[j];
            }
        }
    }
    free(cur);
}

void sort_matrix(int ***a, int n, int m, int *sums) {
    int cur_sum = 0;
    for (int j = 0; j < n - 1; j++) {
        for (int i = 0; i < n - 1; i++) {
            if (sums[i] > sums[i + 1]) {
                swap_str(a, i, n, m);
                cur_sum = sums[i];
                sums[i] = sums[i + 1];
                sums[i + 1] = cur_sum;
            }
        }
    }
}


void output(int **a, int n, int m) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d", a[i][j]);
}

