#include <stdio.h>
#include <stdlib.h>

int input(int ***matrix, int *n, int *m);
void output(int **matrix, int n, int m);
void sum(int **matrix_first, int n_first, int m_first, int **matrix_second);
void mul(int **matrix_first, int n_first, int m_first,
         int **matrix_second, int m_second, int ***matrix_result);
int alloc(int ***a, int *n, int *m, int f);
void transpose(int **matrix, int n, int m, int ***matrix_result);

int main() {
    int **matrix_first, n_first, m_first, **matrix_second, k;
    int n_second, m_second, **matrix_result;
    if (scanf("%d", &k) &&
        (k == 1 || k == 2 || k == 3)) {
        if (k == 1) {
            if (alloc(&matrix_first, &n_first, &m_first, 1) &&
                alloc(&matrix_second, &n_second, &m_second, 1)) {
                if (n_first == n_second && m_first == m_second) {
                    sum(matrix_first, n_first, m_first, matrix_second);
                    output(matrix_first, n_first, m_first);
                    free(matrix_first);
                    free(matrix_second);
                } else {
                    free(matrix_first);
                    free(matrix_second);
                    printf("n/a");
                }
            } else {
                printf("n/a");
            }
        } else if (k == 2) {
            if (alloc(&matrix_first, &n_first, &m_first, 1) &&
                alloc(&matrix_second, &n_second, &m_second, 1)) {
                if (m_first == n_second) {
                    alloc(&matrix_result, &n_first, &m_second, 0);
                    mul(matrix_first, n_first, m_first,
                        matrix_second, m_second, &matrix_result);
                    output(matrix_result, n_first, m_second);
                    free(matrix_first);
                    free(matrix_second);
                    free(matrix_result);
                } else {
                    free(matrix_first);
                    free(matrix_second);
                    free(matrix_result);
                    printf("n/a");
                }
            } else {
                printf("n/a");
            }
        } else if (k == 3) {
            if (alloc(&matrix_first, &n_first, &m_first, 1)) {
                alloc(&matrix_result, &n_first, &m_first, 0);
                transpose(matrix_first, n_first, m_first, &matrix_result);
                output(matrix_result, n_first, m_first);
                free(matrix_first);
                free(matrix_result);
            } else {
                printf("n/a");
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
}

int alloc(int ***a, int *n, int *m, int f) {
    if (f) {
        if (scanf("%d%d", n, m) == 2) {
            *a = (int**)malloc((*n) * (*m) * sizeof(int) + (*n) * sizeof(int*));
            int *ptr = (int*)(*a + (*n));
            for (int i = 0; i < *n; i++)
            (*a)[i] = ptr + (*m) * i;
            if (input(a, n, m)) {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    } else {
        *a = (int**)malloc((*n) * (*m) * sizeof(int) + (*n) * sizeof(int*));
        int *ptr = (int*)(*a + (*n));
        for (int i = 0; i < *n; i++)
        (*a)[i] = ptr + (*m) * i;
    }
    return 1;
}

int input(int ***matrix, int *n, int *m) {
    int a_el;
    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *m; j++) {
            if (scanf("%d", &a_el))
                (*matrix)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

void sum(int **matrix_first, int n_first, int m_first, int **matrix_second) {
    for (int i = 0; i < n_first; i++) {
        for (int j = 0; j < m_first; j++) {
            matrix_first[i][j] += matrix_second[i][j];
        }
    }
}

void mul(int **matrix_first, int n_first, int m_first,
         int **matrix_second, int m_second, int ***matrix_result) {
    for (int i = 0; i < n_first; i++) {
        for (int j = 0; j < m_second; j++) {
            for (int k = 0; k < m_first; k++) {
                (*matrix_result)[i][j] +=
                matrix_first[i][k] * matrix_second[k][j];
            }
        }
    }
}

void transpose(int **matrix, int n, int m, int ***matrix_result) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            (*matrix_result)[j][i] = matrix[i][j];
        }
    }
}

void output(int **matrix, int n, int m) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("%d", matrix[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", matrix[i][j]);
    }
    printf("%d", matrix[i][j]);
}
