#include <stdio.h>
#include <stdlib.h>
#define NMAX 100

int alloc1(int ***a, int n, int m);
int alloc2(int ***a, int n, int m);
int alloc3(int ***a, int n, int m);
int stat(int a[][NMAX], int n, int m);
void output(int **a, int n, int m, int *max, int *min);
void stat_output(int a[][NMAX], int n, int m, int *max, int *min);
void maximum(int **a, int n, int m, int **max);
void minimum(int **a, int n, int m, int **min);
void maximum_stat(int a[][NMAX], int n, int m, int max[NMAX]);
void minimum_stat(int a[][NMAX], int n, int m, int min[NMAX]);

int main() {
    int n, m, k, **arr, st[NMAX][NMAX], *max;
    int *min, max_stat[NMAX], min_stat[NMAX];
    if (scanf("%d", &k) &&
        (k == 1 || k == 2 ||
         k == 3 || k == 4)) {
        if (scanf("%d%d", &n, &m) == 2) {
            if (k == 2) {
                if (alloc1(&arr, n, m)) {
                    maximum(arr, n, m, &max);
                    minimum(arr, n, m, &min);
                    output(arr, n, m, max, min);
                    free(arr);
                    free(max);
                    free(min);
                } else {
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 3) {
                if (alloc2(&arr, n, m)) {
                    maximum(arr, n, m, &max);
                    minimum(arr, n, m, &min);
                    output(arr, n, m, max, min);
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                    free(max);
                    free(min);
                } else {
                    for (int i = 0; i < n; i++)
                        free(arr[i]);
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 4) {
                if (alloc3(&arr, n, m)) {
                    maximum(arr, n, m, &max);
                    minimum(arr, n, m, &min);
                    output(arr, n, m, max, min);
                    free(arr);
                    free(max);
                    free(min);
                } else {
                    free(arr);
                    printf("n/a");
                }
            } else if (k == 1) {
                if (stat(st, n, m)) {
                    maximum_stat(st, n, m, max_stat);
                    minimum_stat(st, n, m, min_stat);
                    stat_output(st, n, m, max_stat, min_stat);
                } else {
                    printf("n/a");
                }
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int stat(int a[][NMAX], int n, int m) {
    int a_el;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                a[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

void maximum(int **a, int n, int m, int **max) {
    *max = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        int maxi = a[i][0];
        for (int j = 0;  j < m; j++) {
            if (a[i][j] > maxi)
                maxi = a[i][j];
        }
        (*max)[i] = maxi;
    }
}

void minimum(int **a, int n, int m, int **min) {
    *min = (int *)malloc(m * sizeof(int));
    for (int i = 0; i < m; i++) {
        int mini = a[0][i];
        for (int j = 0; j < n; j++) {
            if (a[j][i] < mini)
                mini = a[j][i];
        }
        (*min)[i] = mini;
    }
}

void maximum_stat(int a[][NMAX], int n, int m, int max[NMAX]) {
    for (int i = 0; i < n; i++) {
        int maxi = a[i][0];
        for (int j = 0;  j < m; j++) {
            if (a[i][j] > maxi)
                maxi = a[i][j];
        }
        max[i] = maxi;
    }
}

void minimum_stat(int a[][NMAX], int n, int m, int min[NMAX]) {
    for (int i = 0; i < m; i++) {
        int mini = a[0][i];
        for (int j = 0; j < n; j++) {
            if (a[j][i] < mini)
                mini = a[j][i];
        }
        min[i] = mini;
    }
}

int alloc1(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * m * sizeof(int) + n * sizeof(int*));
    int *ptr = (int*)(*a + n);
    for (int i = 0; i < n; i++)
        (*a)[i] = ptr + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc2(int ***a, int n, int m) {
    int a_el;
    *a = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < m; i++)
        (*a)[i] = (int*)malloc(m * sizeof(int*));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc3(int ***a, int n, int m) {
    int a_el;
    *a = malloc(n * sizeof(int*));
    int *values = (int*)malloc(m * n * sizeof(int));
    for (int i = 0; i < n; i++)
        (*a)[i] = values + m * i;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a_el))
                (*a)[i][j] = a_el;
            else
                return 0;
        }
    }
    free(values);
    return 1;
}

void output(int **a, int n, int m, int *max, int *min) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d\n", a[i][j]);
    for (j = 0; j < n - 1; j++) {
        printf("%d ", max[j]);
    }
    printf("%d\n", max[j]);
    for (j = 0; j < m - 1; j++) {
        printf("%d ", min[j]);
    }
    printf("%d", min[j]);
}

void stat_output(int a[][NMAX], int n, int m, int max[NMAX], int min[NMAX]) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d\n", a[i][j]);
    for (j = 0; j < n - 1; j++) {
        printf("%d ", max[j]);
    }
    printf("%d\n", max[j]);
    for (j = 0; j < m - 1; j++) {
        printf("%d ", min[j]);
    }
    printf("%d", min[j]);
}
