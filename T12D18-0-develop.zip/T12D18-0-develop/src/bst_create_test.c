#include <stdio.h>
#include "bst.h"

void test_tree();

int main() {
    test_tree();
    return 0;
}

void test_tree() {
    t_btree *root1 = bstree_create_node(1);
    printf("Test #1: Число в корне №1: %d\n", root1->data);
    t_btree *root2 = bstree_create_node(10);
    printf("Test #2: Число в корне №2: %d", root2->data);
    free(root1);
    free(root2);
}
