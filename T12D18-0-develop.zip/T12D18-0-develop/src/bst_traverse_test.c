#include <stdio.h>
#include "bst.h"
#define N 5

void test_tree();

int main() {
    test_tree();
    return 0;
}

void test_tree() {
    int arr1[N] = {1, -3, 5, -4, 2};
    t_btree *root1 = bstree_create_node(0);
    for (int i = 0; i < N; i++) {
        t_btree *elem = bstree_create_node(arr1[i]);
        bstree_insert(root1, elem, comp);
    }
    printf("Для каждого узла выводятся");
    printf("адреса его левого и правого потомков:\n");
    printf("Test #1: Вывод по возрастанию : ");
    bstree_apply_infix(root1, apply);
    printf("\n");
    printf("Test #1: Вывод по факту : ");
    bstree_apply_prefix(root1, apply);
    printf("\n");
    printf("Test #1: Вывод по убыванию : ");
    bstree_apply_postfix(root1, apply);
    printf("\n");
    destroy(root1);
    int arr2[N] = {1, 1, 1, 1, 1};
    t_btree *root2 = bstree_create_node(0);
    for (int i = 0; i < N; i++) {
        t_btree *elem = bstree_create_node(arr2[i]);
        bstree_insert(root2, elem, comp);
    }
    printf("Для каждого узла выводятся адреса");
    printf("его левого и правого потомков:\n");
    printf("Test #2: Вывод по возрастанию : ");
    bstree_apply_infix(root1, apply);
    printf("\n");
    printf("Test #2: Вывод по факту : ");
    bstree_apply_prefix(root1, apply);
    printf("\n");
    printf("Test #2: Вывод по убыванию : ");
    bstree_apply_postfix(root1, apply);
    printf("\n");
    destroy(root2);
}
