#include <stdlib.h>
#ifndef SRC_BST_H_
#define SRC_BST_H_

typedef struct s_btree {
    struct s_btree *left;
    struct s_btree *right;
    int data;
} t_btree;

t_btree *bstree_create_node(int data);
int comp(int a, int b);
void bstree_insert(t_btree *root, t_btree *elem, int(*cmpf) (int, int));
void bstree_apply_prefix(t_btree *root, void(*applyf) (int));
void bstree_apply_postfix(t_btree *root, void(*applyf) (int));
void bstree_apply_infix(t_btree *root, void(*applyf) (int));
void apply(int data);
void insert_test(t_btree *root);
void destroy(t_btree *root);

#endif  // SRC_BST_H_
