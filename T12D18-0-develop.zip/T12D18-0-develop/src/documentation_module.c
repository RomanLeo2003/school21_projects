#include "documentation_module.h"
#include <vararg.h>

int validate(char* data) {
    int validation_result = !strcmp(data, Available_document);
    return validation_result;
}

int *check_available_documentation_module(int (*val)(char*),
                                          int document_count, ...) {
    int *checks = malloc(document_count * sizeof(int));
    for (int i = 0; i < document_count; i++) {
        checks[i] = val(file_names[i]);
    }
}

void output(int *checks) {
    for (int i = 0; i < Documents_count; i++) {
        printf("%s: %d", Documents[i], checks[i]);
    }
}
