#include <stdio.h>
#include "bst.h"
#define N 5

void test_tree();

int main() {
    test_tree();
    return 0;
}

void test_tree() {
    int arr1[N] = {1, -3, 5, -4, 2};
    t_btree *root1 = bstree_create_node(0);
    for (int i = 0; i < N; i++) {
        t_btree *elem = bstree_create_node(arr1[i]);
        bstree_insert(root1, elem, comp);
    }
    printf("Для каждого узла выводятся");
    printf("адреса его левого и правого потомков:\n");
    printf("Test #1: ");
    printf("Корень дерева имеет адрес");
    printf("[%p] и значение (%d)\n", root1, root1->data);
    insert_test(root1);
    printf("\n");
    destroy(root1);
    int arr2[N] = {1, 1, 1, 1, 1};
    t_btree *root2 = bstree_create_node(0);
    for (int i = 0; i < N; i++) {
        t_btree *elem = bstree_create_node(arr2[i]);
        bstree_insert(root2, elem, comp);
    }
    printf("Test #2: ");
    printf("Корень дерева имеет адрес");
    printf("[%p] и значение (%d)\n", root2, root2->data);
    insert_test(root2);
    destroy(root2);
}

