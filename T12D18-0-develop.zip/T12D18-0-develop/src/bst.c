#include "bst.h"
#include <stdlib.h>
#include <stdio.h>

t_btree *bstree_create_node(int data) {
    t_btree *new_elem = malloc(sizeof(t_btree));
    new_elem->data = data;
    new_elem->left = NULL;
    new_elem->right = NULL;
    return new_elem;
}

int comp(int a, int b) {
    return 1 ? (a > b) : 0;
}

void bstree_insert(t_btree *root, t_btree *elem, int(*cmpf) (int, int)) {
    if (root != NULL) {
        if (cmpf(root->data, elem->data)) {
            if (root->left == NULL) {
                root->left = elem;
            } else {
                bstree_insert(root->left, elem, cmpf);
            }
        } else {
            if (root->right == NULL) {
                root->right = elem;
            } else {
                bstree_insert(root->right, elem, cmpf);
            }
        }
    }
}

void apply(int data) {
    printf("%d ", data);
}

void insert_test(t_btree *root) {
    printf("Правый потомок у числа [%d] имеет адрес: [%p]\n", root->data, root->right);
    printf("Левый потомок у числа [%d] имеет адрес: [%p]\n", root->data, root->left);
    if (root->right != NULL) {
        insert_test(root->right);
    }
    if (root->left != NULL) {
        insert_test(root->left);
    }
}

void bstree_apply_prefix(t_btree *root, void(*applyf) (int)) {
    if (root == NULL) return;
    if (root->data)
        applyf(root->data);
    bstree_apply_prefix(root->right, applyf);
    bstree_apply_prefix(root->left, applyf);
}

void bstree_apply_postfix(t_btree *root, void(*applyf) (int)) {
    if (root->right != NULL)
        bstree_apply_postfix(root->right, applyf);
    applyf(root->data);
    if (root->left != NULL)
        bstree_apply_postfix(root->left, applyf);
}

void bstree_apply_infix(t_btree *root, void(*applyf) (int)) {
    if (root->left != NULL)
        bstree_apply_infix(root->left, applyf);
    applyf(root->data);
    if (root->right != NULL)
        bstree_apply_infix(root->right, applyf);
}

void destroy(t_btree *root) {
    if (root) {
        t_btree *cur_r = root->right;
        t_btree *cur_l = root->left;
        free(root);
        destroy(cur_r);
        destroy(cur_l);
    }
}
