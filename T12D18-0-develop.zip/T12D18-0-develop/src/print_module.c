#include <stdio.h>
#include <time.h>
#include "print_module.h"

char print_char(char ch)  {
    return putchar(ch);
}

void print_log(char (*print)(char), char* message) {
    int j = 0;
    const time_t t = time(NULL);
    struct tm *u = localtime(&t);
    while (Log_prefix[j]) {
        print(Log_prefix[j]);
        j++;
    }
    print(' ');
    j = 0;
    char ti[11];
    sprintf(ti, "%02d:%02d:%02d ", u->tm_hour, u->tm_min, u->tm_sec);
    while (ti[j]) {
        print(ti[j]);
        j++;
    }
    j = 0;
    while (message[j]) {
        print(message[j]);
        j++;
    }
}
