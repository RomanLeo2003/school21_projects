#include <stdio.h>
#include <stdlib.h>

int alloc(int ***matrix, int *n, int *m);
void output(int **matr, int n, int m);
void sort_matrix(int ***matr, int n, int m, int ***matrix1);
void sort(int *a, int n);
void inverse_sort(int *a, int n);
void in_arr(int **matr, int n, int m, int **a);
void in_matr(int ***matr, int n, int m, int *a);
void transpose(int **matrix, int n, int m, int ***matrix_result);



int main() {
	int **matrix, n, m, **matrix1;
	alloc(&matrix, &n, &m);
	sort_matrix(&matrix, n, m, &matrix1);
	output(matrix1, n, m);
	printf("\n");
	output(matrix, n, m);

	for (int i = 0; i < n; i++)
		free(matrix[i]);
	free(matrix);

	for (int i = 0; i < n; i++)
		free(matrix1[i]);
	free(matrix1);
	return 0;
}

int input(int ***matrix, int n, int m) {
	int a;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			scanf("%d", &a);
			(*matrix)[i][j] = a;
		}
	}
	return 1;
}

int alloc(int ***matrix, int *n, int *m) {
	scanf("%d%d", n, m);
	(*matrix) = (int**)malloc(*n * sizeof(int*));
	for (int i = 0; i < *n; i++) {
		(*matrix)[i] = (int*)malloc(*m * sizeof(int));
	}
	input(matrix, *n, *m);
	return 1;
}

void sort_matrix(int ***matr, int n, int m, int ***matrix1) {
	int *arr;
	in_arr((*matr), n, m, &arr);
	sort(arr, n * m);

	in_matr(&(*matr), n, m, arr);


	for (int i = 0; i < n; i++) {
		if (i % 2 == 1) {
			inverse_sort((*matr)[i], m);
		}
		else {
			sort((*matr)[i], m);
		}
	}
	(*matrix1) = (int**)malloc(n * sizeof(int*));
	for (int i = 0; i < n; i++) {
		(*matrix1)[i] = (int*)malloc(m * sizeof(int));
	}
	transpose((*matr), n, m, matrix1);
	free(arr);
}


void transpose(int **matrix, int n, int m, int ***matrix_result) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			(*matrix_result)[j][i] = matrix[i][j];
		}
	}
}


void in_arr(int **matr, int n, int m, int **a) {
	(*a) = (int*)malloc(n * m * sizeof(int));
	int c = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			(*a)[c] = matr[i][j];
			c++;
		}
	}
}

void in_matr(int ***matr, int n, int m, int *a) {
	int c = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			(*matr)[i][j] = a[c];
			c++;
		}
	}
}

void output(int **matr, int n, int m) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			printf("%d ", matr[i][j]);
		}
		printf("\n");
	}
}

void sort(int *a, int n) {
	int cur = 0;
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - 1; j++) {
			if (a[j] > a[j + 1]) {
				cur = a[j];
				a[j] = a[j + 1];
				a[j + 1] = cur;
			}
		}
	}
}

void inverse_sort(int *a, int n) {
	int cur = 0;
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - 1; j++) {
			if (a[j] < a[j + 1]) {
				cur = a[j];
				a[j] = a[j + 1];
				a[j + 1] = cur;
			}
		}
	}
}
