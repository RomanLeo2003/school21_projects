#include <stdio.h>
#include <stdlib.h>


int alloc(int ***matrix, int *n, int *m);
void output(int **matr, int n, int m);
void sort_matrix(int ***matr, int n, int m, int ***matrix1);
void sort(int *a, int n);
void inverse_sort(int *a, int n);
void in_arr(int **matr, int n, int m, int **a);
void in_matr(int ***matr, int n, int m, int *a);
void transpose(int **matrix, int n, int m, int ***matrix_result);
void sort_vertical(int **matrix, int n, int m, int **result_matrix);
void sort_horizontal(int **matrix, int n, int m, int **result_matrix);

int main() {
    int **matrix, n, m, **matrix1;
    if (alloc(&matrix, &n, &m)) {
        sort_matrix(&matrix, n, m, &matrix1);
        output(matrix1, m, n);
        printf("\n\n");
        output(matrix, n, m);
        for (int i = 0; i < n; i++)
            free(matrix[i]);
        free(matrix);
        for (int i = 0; i < n; i++)
            free(matrix1[i]);
        free(matrix1);
    } else {
        for (int i = 0; i < n; i++)
            free(matrix[i]);
        free(matrix);
        for (int i = 0; i < n; i++)
            free(matrix1[i]);
        free(matrix1);
        printf("n/a");
    }
    return 0;
}

int input(int ***matrix, int n, int m) {
    int a;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &a)) {
                (*matrix)[i][j] = a;
            } else {
                return 0;
            }
        }
    }
    return 1;
}

int alloc(int ***matrix, int *n, int *m) {
    if (scanf("%d", n) && *n > 0
       && scanf("%d", m) && *m > 0) {
        (*matrix) = (int**)malloc((*n) * sizeof(int*));
        for (int i = 0; i < *n; i++) {
            (*matrix)[i] = (int*)malloc((*m) * sizeof(int));
        }
        if (!input(matrix, *n, *m)) {
            return 0;
        }
    } else {
        return 0;
    }
    return 1;
}

void sort_matrix(int ***matr, int n, int m, int ***matrix1) {
    int *arr;
    in_arr((*matr), n, m, &arr);
    sort(arr, n * m);

    in_matr(&(*matr), n, m, arr);


    for (int i = 0; i < n; i++) {
        if (i % 2 == 1) {
            inverse_sort((*matr)[i], m);
        } else {
            sort((*matr)[i], m);
        }
    }
    transpose((*matr), n, m, matrix1);
    free(arr);
}

void transpose(int **matrix, int n, int m, int ***matrix_result) {
    (*matrix_result) = (int**)malloc(m * sizeof(int*));
    for (int i = 0; i < m; i++) {
        (*matrix_result)[i] = (int*)malloc(n * sizeof(int));
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            (*matrix_result)[j][i] = matrix[i][j];
        }
    }
}


void in_arr(int **matr, int n, int m, int **a) {
    (*a) = (int*)malloc(n * m * sizeof(int));
    int c = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            (*a)[c] = matr[i][j];
            c++;
        }
    }
}

void in_matr(int ***matr, int n, int m, int *a) {
    int c = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            (*matr)[i][j] = a[c];
            c++;
        }
    }
}

void output(int **a, int n, int m) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < m - 1; j++) {
            printf("%d ", a[i][j]);
        }
        printf("%d", a[i][j]);
        printf("\n");
    }
    for (j = 0; j < m - 1; j++) {
        printf("%d ", a[i][j]);
    }
    printf("%d", a[i][j]);
}

void sort(int *a, int n) {
    int cur = 0;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1; j++) {
            if (a[j] > a[j + 1]) {
                cur = a[j];
                a[j] = a[j + 1];
                a[j + 1] = cur;
            }
        }
    }
}

void inverse_sort(int *a, int n) {
    int cur = 0;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1; j++) {
            if (a[j] < a[j + 1]) {
                cur = a[j];
                a[j] = a[j + 1];
                a[j + 1] = cur;
            }
        }
    }
}

