#include <stdio.h>
#include <stdlib.h>

int input(double ***matrix, int *n, int *m);
void matrix_without(double **matrix, int size,
                    int row, int col, double **newMatrix);
double det(double **matrix, int size);
int alloc(double ***a, int *n, int *m);

int main() {
    double **matrix;
    int n, m;
    if (alloc(&matrix, &n, &m)) {
        printf("%lf", det(matrix, n));
        free(matrix);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(double ***matrix, int *n, int *m) {
    int a_el;
    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *m; j++) {
            if (scanf("%d", &a_el))
                (*matrix)[i][j] = a_el;
            else
                return 0;
        }
    }
    return 1;
}

int alloc(double ***a, int *n, int *m) {
    if (scanf("%d%d", n, m) == 2) {
        *a = (double**)malloc((*n) * (*m) * sizeof(double) +
                              (*n) * sizeof(double*));
        double *ptr = (double*)(*a + (*n));
        for (int i = 0; i < *n; i++)
        (*a)[i] = ptr + (*m) * i;
        if (input(a, n, m)) {
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0;
    }
    return 1;
}


void matrix_without(double **matrix, int size,
                    int row, int col, double **newMatrix) {
    int offset_row = 0;
    int offset_col = 0;
    for (int i = 0; i < size-1; i++) {
        if (i == row) {
            offset_row = 1;
        }
        offset_col = 0;
        for (int j = 0; j < size-1; j++) {
            if (j == col) {
                offset_col = 1;
            }
            newMatrix[i][j] = matrix[i + offset_row][j + offset_col];
        }
    }
}

double det(double **matrix, int size) {
    int d = 0;
    int degree = 1;
    if (size == 1) {
        return matrix[0][0];
    } else if (size == 2) {
        return matrix[0][0]*matrix[1][1] - matrix[0][1]*matrix[1][0];
    } else {
        double **newMatrix = (double**)malloc((size - 1) * sizeof(double*));
        for (int i = 0; i < size-1; i++) {
            newMatrix[i] = (double*)malloc((size - 1) * sizeof(double));
        }
        for (int j = 0; j < size; j++) {
            matrix_without(matrix, size, 0, j, newMatrix);
            d = d + (degree * matrix[0][j] * det(newMatrix, size-1));
            degree = -degree;
        }
        for (int i = 0; i < size-1; i++) {
            free(newMatrix[i]);
        }
        free(newMatrix);
    }
    return d;
}
