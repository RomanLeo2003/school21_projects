#include <stdio.h>
#include <stdlib.h>
#ifndef SRC_DOOR_STRUCT_H_
#define SRC_DOOR_STRUCT_H_

struct door {
    int id;
    int status;
};

void initialize_doors(struct door* doors);
void sort(struct door *a, int n);
void output(struct door* doors, int n);
void set_close(struct door* doors, int n);

#endif  //  SRC_DOOR_STRUCT_H_
