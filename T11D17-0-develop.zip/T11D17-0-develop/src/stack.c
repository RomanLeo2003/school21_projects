#include "stack.h"
#include <stdlib.h>
#include <stdio.h>

struct stack *init(int data) {
    struct stack *new_stack = malloc(sizeof(struct stack));
    new_stack->data = data;
    new_stack->Next = NULL;
    return new_stack;
}

struct stack *push(struct stack *head, int data) {
    struct stack *new_stack = init(data);
    new_stack->Next = head;
    head = new_stack;
    return head;
}

struct stack *pop(struct stack *head) {
    struct stack *cur;
    if (head != NULL) {
        cur = head;
        head = head->Next;
        free(cur);
    }
    return head;
}

void destroy(struct stack **head) {
    if ((*head) != NULL) {
        struct stack* to_del = (*head);
        while (to_del != NULL && (*head) != NULL) {
            (*head) = (*head)->Next;
            free(to_del);
            to_del = (*head);
        }
    }
}

int len_stack(struct stack* head) {
    int len = 0;
    if (head != NULL) {
        struct stack* cur = head;
        while (cur != NULL) {
            len++;
            cur = cur->Next;
        }
    }
    return len;
}

void output_stack(struct stack *head) {
    struct stack *cur = head;
    for (int i = 0; i < len_stack(head); i++) {
        printf("%d ", cur->data);
        cur =  cur->Next;
    }
}
