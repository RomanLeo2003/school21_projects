#include <stdio.h>
#include <stdlib.h>
#ifndef SRC_STACK_H_
#define SRC_STACK_H_

struct stack {
    int data;
    struct stack *Next;
};

struct stack *init(int data);
struct stack *push(struct stack *last, int data);
struct stack *pop(struct stack *head);
void destroy(struct stack **root);
int len_stack(struct stack* head);
void output_stack(struct stack *head);

#endif  // SRC_STACK_H_
