#include "door_struct.h"
#include <stdio.h>
#include <stdlib.h>
#ifndef SRC_LIST_H_
#define SRC_LIST_H_

struct node {
    struct door *data;
    struct node *Next;
};

struct node *init(struct door *door);
struct node *add_door(struct node* elem, struct door *door);
struct node* find_door(int door_id, struct node* root);
struct node* remove_door(struct node* elem, struct node* root);
void destroy(struct node** root);
void output_list(struct node* root);
int len_list(struct node* root);

#endif  //  SRC_LIST_H_
