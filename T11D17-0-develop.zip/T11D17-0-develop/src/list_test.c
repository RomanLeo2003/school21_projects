#include "door_struct.h"
#include "list.h"

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#define D_CNT 3
#define MAX_ID_SEED 10000

void test_1();
void test_2();
void test_3();

int main() {
    test_1();
    test_2();
    test_3();
}

void test_1() {
    struct door doors[D_CNT];
    srand(time(0));
    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < D_CNT; i++) {
        doors[i].id = (i + seed) % D_CNT;
        doors[i].status = rand() % 2;
    }
    struct node *n1 = init(&doors[0]);
    struct node *n5 = add_door(n1, &doors[1]);
    if (n5->data->id == doors[1].id && len_list(n1) == 2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    remove_door(n5, n1);
    if (len_list(n1) == 1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    destroy(&n1);
}


void test_2() {
    struct door doors[D_CNT];
    srand(time(0));
    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < D_CNT; i++) {
        doors[i].id = (i + seed) % D_CNT;
        doors[i].status = rand() % 2;
    }
    struct node *n1 = init(&doors[0]);
    struct node *n2 = add_door(n1, &doors[1]);
    struct node *n3;
    add_door(n2, &doors[2]);
    n3 = find_door(doors[2].id, n1);
    if (len_list(n1) == 3 && n3->data->status == doors[2].status) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    remove_door(n3, n2);
    remove_door(n2, n1);
    if (len_list(n1) == 1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    destroy(&n1);
}

void test_3() {
    struct door doors[D_CNT];
    srand(time(0));
    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < D_CNT; i++) {
        doors[i].id = (i + seed) % D_CNT;
        doors[i].status = rand() % 2;
    }
    struct node *n1 = init(&doors[0]);
    struct node *n2 = add_door(n1, &doors[1]);
    struct node *n3 = add_door(n2, NULL);
    if (len_list(n1) == 2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    remove_door(n3, n1);
    destroy(&n1);
    if (len_list(n1) == 0 && !n1) {
        printf("SUCCESS");
    } else {
        printf("FAIL");
    }
}
