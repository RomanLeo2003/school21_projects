#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "door_struct.h"
#define DOORS_COUNT 15
#define MAX_ID_SEED 10000

void initialize_doors(struct door* doors);
void sort(struct door *a, int n);
void output(struct door* doors, int n);
void set_close(struct door* doors, int n);

int main() {
    struct door doors[DOORS_COUNT];
    initialize_doors(doors);
    set_close(doors, DOORS_COUNT);
    sort(doors, DOORS_COUNT);
    output(doors, DOORS_COUNT);
    return 0;
}

void sort(struct door *a, int n) {
    int i = 0;
    int j = n - 1;
    int mid = a[n / 2].id;
    do {
        while (a[i].id < mid)
            i++;
        while (a[j].id > mid)
            j--;
        if (i <= j) {
            int tmp = a[i].id;
            a[i].id = a[j].id;
            a[j].id = tmp;
            i++;
            j--;
        }
    } while (i <= j);

    if (j > 0) {
        sort(a, j + 1);
    }
    if (i < n) {
        sort(&a[i], n - i);
    }
}

void set_close(struct door* doors, int n) {
    for (int i = 0; i < n; i++)
        doors[i].status = 0;
}

void output(struct door* doors, int n) {
    int i;
    for (i = 0; i < n - 1; i++)
        printf("%d, %d\n", doors[i].id, doors[i].status);
    printf("%d, %d", doors[i].id, doors[i].status);
}

void initialize_doors(struct door* doors) {
    srand(time(0));
    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < DOORS_COUNT; i++) {
        doors[i].id = (i + seed) % DOORS_COUNT;
        doors[i].status = rand() % 2;
    }
}
