#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

void test_1();
void test_2();
void test_3();

int main() {
    test_1();
    test_2();
    test_3();
    return 0;
}

void test_1() {
    struct stack *s1 = NULL;
    s1 = push(s1, 1);
    s1 = push(s1, 2);
    if (s1->data == 2 && len_stack(s1)) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    s1 = pop(s1);
    if (len_stack(s1) == 1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    destroy(&s1);
}

void test_2() {
    struct stack *s1 = NULL;
    s1 = push(s1, 1);
    s1 = push(s1, s1->data);
    if (s1->data == 1 && len_stack(s1) == 2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    s1 = pop(s1);
    if (len_stack(s1) == 1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    destroy(&s1);
}

void test_3() {
    struct stack *s1 = NULL;
    s1 = push(s1, 1);
    s1 = push(s1, 2);
    if (s1->data == 2 && len_stack(s1) == 2) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    s1 = pop(s1);
    s1 = pop(s1);
    s1 = pop(s1);
    s1 = pop(s1);
    s1 = pop(s1);
    if (len_stack(s1) == 0 && !s1) {
        printf("SUCCESS");
    } else {
        printf("FAIL");
    }
    destroy(&s1);
}

