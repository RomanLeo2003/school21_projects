#include "door_struct.h"
#include "list.h"
#include <stdlib.h>
#include <stdio.h>

struct node *init(struct door *door) {
    struct node *new_node = NULL;
    char *ptr = malloc(1);
    if (door != NULL && ptr != NULL) {
        new_node = malloc(sizeof(struct node));
        new_node->data = door;
        new_node->Next = NULL;
    }
    free(ptr);
    return new_node;
}

struct node *add_door(struct node* elem, struct door *door) {
    struct node *new_node = NULL;
    if (elem != NULL && door != NULL) {
        new_node = init(door);
        new_node->Next = elem->Next;
        elem->Next = new_node;
    }
    return new_node;
}

struct node* find_door(int door_id, struct node* root) {
    struct node *current;
    if (root != NULL) {
        current = root;
        while (current->data->id != door_id)
            current = current->Next;
    }
    return current;
}

struct node* remove_door(struct node* elem, struct node* root) {
    struct node *current;
    if (!(elem == root)) {
        if (elem != NULL && root != NULL) {
            current = root;
            while (current->Next != elem)
                current = current->Next;
            current->Next = elem->Next;
        }
        free(elem);
    } else {
        free(root);
        root = NULL;
    }
    return root;
}

void destroy(struct node** root) {
    if ((*root) != NULL) {
        struct node* to_del = (*root);
        while (to_del != NULL && (*root) != NULL) {
            (*root) = (*root)->Next;
            free(to_del);
            to_del = (*root);
        }
    }
}

void output_list(struct node* root) {
    if (root != NULL) {
        while (root != NULL) {
            printf("%d, %d\n", root->data->id, root->data->status);
            root = root->Next;
        }
    }
}

int len_list(struct node* root) {
    int len = 0;
    if (root != NULL) {
        struct node* cur = root;
        while (cur != NULL) {
            len++;
            cur = cur->Next;
        }
    }
    return len;
}
