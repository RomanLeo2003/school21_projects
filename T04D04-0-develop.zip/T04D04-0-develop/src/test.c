#include <stdio.h>

int main() {
    int x;
    int scan = scanf("%X", &x);
    printf("%X %d", x, scan);
    return 0;
}
