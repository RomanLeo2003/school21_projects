#include <stdio.h>
#include <math.h>

double pi = 3.1415927;


double vers(double x) {
    return 1 / (1 + x * x);
}

double lemniskat(double x) {
    return pow(pow(1 + 4 * x * x, 0.5) -  x * x - 1, 0.5);
}

double hip(double x) {
    return 1 / pow(x,  2);
}

int main() {
    double x = -pi;
    double step = (2 * pi) / 41;
    for (int i = 0; i < 42; i++) {
        printf("%.7lf | ", x);
        printf("%.7lf | ", vers(x));
        if ((pow((1 + 4 * x * x), 0.5) -  x * x - 1) >= 0)
            printf("%.7lf | ", lemniskat(x));
        else
            printf("- | ");
        if ( x != 0)
            printf("%.7lf\n", hip(x));
        else
            printf("- \n");
        x += step;
    }
    return 0;
}
