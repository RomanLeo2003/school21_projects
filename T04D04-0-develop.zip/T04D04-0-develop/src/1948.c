#include <stdio.h>


int is_simple(int x) {
    int y = x / 2, n = 0, ix = x;
    while (y > 1) {
        while (ix >= y) {
            ix -= y;
            n++;
        }
        if (n * y == x)
            return 0;
        y--;
        n = 0;
        ix = x;
    }
    return 1;
}

int max_factor(int x) {
    int y = x / 2, n = 0, ix = x;
    while (y > 1) {
        while (ix >= y) {
            ix -= y;
            n++;
        }
        if (n * y == x && is_simple(y))
            return y;
        y--;
        n = 0;
        ix = x;
    }
    return x;
}

int main() {
    int n;
    char c;
    int scan = scanf("%d%c", &n, &c);
    if (scan == 2 && c == '\n' && n != 0 && n != 1 && n != -1) {
        if (n > 0)
            printf("%d", max_factor(n));
        else
            printf("%d", max_factor(-n));
    } else {
        printf("n/a");
    }
    return 0;
}
