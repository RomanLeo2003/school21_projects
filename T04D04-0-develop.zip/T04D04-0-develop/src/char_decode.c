#include <stdio.h>

void coder() {
    char c;
    char ch;
    while (1) {
        if (scanf("%c%c", &c, &ch) != 2 || (ch != ' ' && ch != '\n')) {
            printf("n/a");
            break;
        }
        if (ch == ' ') {
            printf("%X ", c);
        } else {
            printf("%X", c);
            break;
        }
    }
}

void decoder() {
    int c;
    char ch;
    while (1) {
        if (scanf("%X%c", &c, &ch) != 2 ||
            (ch != ' ' && ch != '\n') ||
            (c < 0x21 && c > 0x7E)) {
            printf("n/a");
            break;
        }
        if (ch == ' ') {
            printf("%c ", c);
        } else {
            printf("%c", c);
            break;
        }
    }
}

int main(int argc, char ** argv) {
    if (argc == 2) {
        char cmd = argv[1][0];
        char end = argv[1][1];
        if (!end) {
            if (cmd == '0')
                coder();
            else if (cmd == '1')
                decoder();
            else
                printf("n/a");
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}


