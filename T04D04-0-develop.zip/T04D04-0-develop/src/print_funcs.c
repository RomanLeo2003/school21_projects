#include <stdio.h>
#include <math.h>

double pi = 3.1415927;
double step = 0.1532485;

double vers(double x) {
    return 1 / (1 + x * x);
}

double lemniskat(double x) {
    return pow(pow(1 + 4 * x * x, 0.5) -  x * x - 1, 0.5);
}

double hip(double x) {
    return 1 / pow(x,  2);
}



int main () {
    int scene_width = 21;
    int scene_length = 42;
    
    char scene[scene_length][scene_width * scene_width];
    for(int x=0;x<scene_length;x++){
        for(int y=0; y < scene_width * scene_width; y++)
            scene[x][y]=' ';
        scene[x][scene_width]='-';
  }

  
    for(int x = 0; x <= scene_length ;x++){
        double y = x * x;
        if (fabs(y) < scene_width)
            scene[x][(int)round(y-scene_width)]='*';
  }
  for(int y=scene_width * 2; y>=0; y--){
      printf ("%c", '|');
      for(int x=0;x<scene_length;x++){
          printf("%c",scene[x][y]);
      }
      printf("\n");
  }
    return 0;
}
