#include <stdio.h>

int fibonacci(int n) {
    if (n == 1 || n == 2) {
        return 1;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

int main() {
    int n;
    char c;
    int scan = scanf("%d%c", &n, &c);
    if (c == '\n' && scan == 2 && n > 0)
        printf("%d", fibonacci(n));
    else
        printf("n/a");
    return 0;
}
