#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int PLATFORM_NAME = 0;

#if defined(__APPLE__) && defined(__MACH__)
#define PLATFORM_NAME 1
#endif

void parser_flags_mac(int argc, char* argv[], int* flags);
void printer(int argc, char* argv[], int* flags);
void parser_flags_gnu(int argc, char* argv[], int* flags);

int main(int argc, char* argv[]) {
  int flags[9] = {0, 0, 0, 0, 0};  // 0b 1e 2n 3s 4t 5v
  if (PLATFORM_NAME)
    parser_flags_mac(argc, argv, flags);
  else
    parser_flags_gnu(argc, argv, flags);
  printer(argc, argv, flags);
  return 0;
}

/*
-b (GNU: --number-nonblank) 0
-e предполагает и -v (GNU only: -E то же самое, но без применения -v) 1
-n (GNU: --number) 2
-s (GNU: --squeeze-blank) 3
-t предполагает и -v (GNU: -T то же самое, но без применения -v) 4
*/

void parser_flags_gnu(int argc, char* argv[], int* flags) {
  for (int i = 1; i < argc; i++) {
    for (int j = 1; argv[i][j]; j++) {
      if (argv[i][0] == '-' && argv[i][1] != '-') {
        switch (argv[i][j]) {
          case '-':
            break;
          case 'b':
            flags[0] = 1;
            break;
          case 'e':
            flags[1] = 1;
            break;
          case 'n':
            flags[2] = 1;
            break;
          case 's':
            flags[3] = 1;
            break;
          case 't':
            flags[4] = 1;
            break;
          case 'v':
            flags[5] = 1;
            break;
          case 'E':
            flags[1] = 1;
            break;
          case 'T':
            flags[4] = 1;
            break;
          default:
            printf("cat: illegal option -- ");
            for (int j = 1; i < argv[i][j]; j++) printf("%c", argv[i][j]);
            printf("\nusage: cat [-benstuv] [file ...]\n");
            exit(1);
        }
      }

      if (argv[i][0] == '-' && argv[i][1] == '-') {
        if (strcmp(argv[i], "--number-nonblank") == 0)
          flags[0] = 1;
        else if (strcmp(argv[i], "--number") == 0)
          flags[2] = 1;
        else if (strcmp(argv[i], "--squeeze-blank") == 0)
          flags[3] = 1;
        else {
          printf("cat: illegal option -- ");
          for (int j = 1; i < argv[i][j]; j++) printf("%c", argv[i][j]);
          printf("\nusage: cat [-benstuv] [file ...]\n");
          exit(1);
        }
      }
    }
  }
}

// 0b 1e 2n 3s 4t 5v
void parser_flags_mac(int argc, char* argv[], int* flags) {
  int file = 0;
  for (int i = 1; i < argc; i++) {
    for (int j = 1; argv[i][j]; j++) {
      if (argv[i][0] != '-') file = 1;
      if (argv[i][0] == '-' && !file) {
        switch (argv[i][j]) {
          case '-':
            break;
          case 'b':
            flags[0] = 1;
            break;
          case 'e':
            flags[1] = 1;
            flags[5] = 1;
            break;
          case 'n':
            flags[2] = 1;
            break;
          case 's':
            flags[3] = 1;
            break;
          case 't':
            flags[4] = 1;
            flags[5] = 1;
            break;
          case 'v':
            flags[5] = 1;
            break;
          default:
            printf("cat: illegal option -- ");
            for (int j = 1; i < argv[i][j]; j++) printf("%c", argv[i][j]);
            printf("\nusage: cat [-benstuv] [file ...]\n");
            exit(1);
        }
      }
    }
  }
}

void printer(int argc, char* argv[], int* flags) {
  char prev, c = '\0';
  int count = 0, stringCount = 1;

  for (int i = 1; i < argc; i++) {
    if (argv[i][0] == '-') continue;
    FILE* fp = fopen(argv[i], "r");
    // if (errno) fprintf(stderr, "cat: %s: %s\n", currentFile,
    // strerror(errno));

    if (fp == NULL) {
      fprintf(stderr, "cat: %s: %s\n", argv[i], strerror(errno));
    } else {
      stringCount = 1;
      c = '\0';

      while (1) {
        prev = c;
        c = fgetc(fp);
        if (c == EOF) break;

        if (c == '\n') {
          count++;
        } else {
          count = 0;
        }

        if ((flags[0] &&
             ((prev == '\n' && c != '\n') || (!prev && c != '\n'))) ||
            (flags[2] && !flags[0] && count <= 2 && flags[3] &&
             (prev == '\n' || !prev)) ||
            (flags[2] && !flags[3] && !flags[0] && (prev == '\n' || !prev))) {
          printf("%6.d\t", stringCount);
          stringCount++;
        }

        //// 0b 1e 2n 3s 4t 5v 6E 7T
        if (flags[4] && c == '\t')
          printf("^I");
        else if (flags[5] && c <= 31 && c != '\n' && c != '\t')
          printf("^%c", (c + 64));
        else if (flags[5] && c == 127)
          printf("^?");
        else if (flags[3] && count >= 3)
          continue;
        else if (flags[1] && c == '\n')
          printf("$\n");
        else {
          printf("%c", c);
        }
      }
      fclose(fp);
    }
  }
}