#include "s21_grep.h"

int main(int argc, char **argv) {
  int flags[11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  if (argc >= 3) {
    parser_flags(argc, argv, flags);
    parser_patterns(argc, argv, flags);
    if (pattern_count > 0 && file_count > 0) printer(flags);
    clean_memeory();
  }
  return 0;
}

void clean_memeory() {
  for (int i = 0; i < patterns_array_size && pattern_count > 0; i++) {
    free(patterns_array[i]);
  }
  free(patterns_array);

  for (int i = 0; i < file_array_size && file_count > 0; i++) {  // kosyachit
    free(files_array[i]);
  }
  free(files_array);
}

void parser_flags(int argc, char *argv[], int *flags) {
  for (int i = 1; i < argc; i++) {
    for (int j = 1; argv[i][j]; j++) {
      if (argv[i][0] == '-') {
        switch (argv[i][j]) {
          case 'e':
            flags[1] = 1;
            break;
          case 'i':
            flags[2] = 1;
            break;
          case 'v':
            flags[3] = 1;
            break;
          case 'c':
            flags[4] = 1;
            break;
          case 'l':
            flags[5] = 1;
            break;
          case 'n':
            flags[6] = 1;
            break;
          case 'h':
            flags[7] = 1;
            break;
          case 's':
            flags[8] = 1;
            break;
          case 'f':
            flags[9] = 1;
            break;
          case 'o':
            flags[10] = 1;
            break;
          default:
            printf("-%c flag doesn't work for the task\n", argv[i][j]);
        }
        if (argv[i][j] == 'e' || argv[i][j] == 'f') {
          if ((argv[i][j + 1]))
            break;
          else {
            i++;
            break;
          }
        }
      }
    }
  }
}

void parser_patterns(int argc, char *argv[], const int *flags) {
  int file_check;
  int default_pattern_check = 0;
  char pattern[BUFFSIZE] = "";
  char patterns_file[BUFFSIZE] = "";

  for (int i = 1; i < argc; i++) {
    file_check = 1;
    for (int count = 0; pattern[count]; count++) pattern[count] = '\0';
    for (int count = 0; patterns_file[count]; count++)
      patterns_file[count] = '\0';
    // if -e || -f flag
    for (int j = 1; argv[i][j] && argv[i][0] == '-'; j++) {
      if (argv[i][j] == 'f' && argv[i][j + 1]) {
        for (j++; argv[i][j]; j++) mystrcatone(patterns_file, argv[i][j]);
        parser_patterns_from_file(patterns_file);
        file_check = 0;
        break;
      } else if (argv[i][j] == 'f') {
        i++;
        parser_patterns_from_file(argv[i]);
        file_check = 0;
        break;
      }

      if (argv[i][j] == 'e' && argv[i][j + 1]) {
        for (j++; argv[i][j]; j++) mystrcatone(pattern, argv[i][j]);
        add_pattern(pattern);
        file_check = 0;
        break;
      } else if (argv[i][j] == 'e') {
        i++;
        add_pattern(argv[i]);
        file_check = 0;
        break;
      }
    }
    // no ef flags
    if (!flags[1] && !flags[9] && argv[i][0] != '-' && !default_pattern_check) {
      add_pattern(argv[i]);
      default_pattern_check = 1;
      continue;
    }
    if (file_check && argv[i][0] != '-') {
      add_file(argv[i]);
    }
  }
}

void add_pattern(char *pattern) {
  if (!patterns_array) {
    patterns_array = (char **)calloc(patterns_array_size, sizeof(char *));
  }
  if (pattern_count >= patterns_array_size) {
    patterns_array_size = pattern_count * 2 + 1;
    patterns_array =
        (char **)realloc(patterns_array, patterns_array_size * sizeof(char *));
  }
  pattern_count++;
  patterns_array[pattern_count - 1] =
      (char *)calloc(strlen(pattern) + 5, sizeof(char));
  patterns_array[pattern_count - 1][0] = '\0';
  strcpy(patterns_array[pattern_count - 1], pattern);
}

void add_file(char *file) {
  if (!files_array) {
    files_array = (char **)calloc(file_array_size, sizeof(char *));
  }
  if (file_count >= file_array_size) {
    file_array_size = file_count * 2 + 1;
    files_array =
        (char **)realloc(files_array, file_array_size * sizeof(char *));
  }
  file_count++;
  files_array[file_count - 1] =
      (char *)calloc((strlen(file) + 5), sizeof(char));
  //  files_array[file_count - 1] = NULL;
  strcpy(files_array[file_count - 1], file);
}

void mystrcatone(char *dst, char src) { dst[strlen(dst)] = src; }

void parser_patterns_from_file(char *patterns_file) {
  char string[BUFFSIZE] = "";
  char prevStr[BUFFSIZE] = "";
  char *file_available;
  FILE *fp = fopen(patterns_file, "r");
  if (!fp) {
    fprintf(stderr, "grep: %s: %s\n", patterns_file, strerror(errno));
  } else {
    while (1) {
      strcpy(prevStr, string);
      file_available = fgets(string, sizeof(string), fp);
      if (string[strlen(string) - 1] == '\n' && strlen(string) != 1)
        string[strlen(string) - 1] = '\0';
      if (file_available == NULL) break;
      add_pattern(string);
    }
  }
  fclose(fp);
}

void printer(int *flags) {
  char string[BUFFSIZE] = "";
  char *estr;
  int files_count = 0;
  for (int i = 0; files_array[i]; i++) files_count++;
  for (int i = 0; files_array[i]; i++) {
    int count_lines_ok_regex = 0;
    int count_lines_ok_regex_flag_4 = 0;
    int count_lines_of_file;
    count_lines_of_file = 0;
    FILE *fp = fopen(files_array[i], "r");
    if (fp == NULL) {
      if (!flags[8])
        fprintf(stderr, "grep: %s: %s\n", files_array[i], strerror(errno));
      continue;
    }
    while (1) {
      estr = fgets(string, sizeof(string), fp);
      if (string[strlen(string) - 1] != '\n') strcat(string, "\n");
      count_lines_of_file++;
      if (estr == NULL) {
        if (feof(fp) != 0) {
          break;
        } else {
          if (!flags[8])
            fprintf(stderr, "grep: %s: %s\n", files_array[i], strerror(errno));
          break;
        }
      }
      if (flags[10] && (flags[3] || flags[4] || flags[5])) flags[10] = 0;
      if (flags[10]) {
        count_lines_ok_regex_flag_4 += regex_o_flag(
            flags, string, count_lines_of_file, files_count, files_array[i]);
      } else {
        if (flags[4] || flags[5] || flags[6]) {
          if (regex(flags, string)) count_lines_ok_regex++;
        } else if (!flags[10] && regex(flags, string)) {
          if (files_count > 1 && !flags[7]) printf("%s:", files_array[i]);
          printf("%s", string);
        }
        // if (flags[5] && count_lines_ok_regex > 0) break;
        if ((flags[6]) && !flags[4] && !flags[5] && regex(flags, string)) {
          if (files_count == 1 || flags[7])
            printf("%d:%s", (count_lines_of_file), string);
          else
            printf("%s:%d:%s", files_array[i], (count_lines_of_file), string);
        }
      }
    }  // END WHILE
    // bugs just for success mac's grep
    if (!flags[10]) {
      if (flags[4] && flags[5] && !flags[7] && PLATFORM_MAC &&
          files_count > 1 && count_lines_ok_regex == 0) {
        printf("%s:0\n", files_array[i]);
      } else if (flags[4] && flags[5] && flags[7] && PLATFORM_MAC &&
                 files_count > 1 && count_lines_ok_regex > 0) {
        printf("1\n%s\n", files_array[i]);
      } else if (flags[4] && flags[5] && PLATFORM_MAC && files_count > 1 &&
                 count_lines_ok_regex > 0) {
        printf("%s:1\n%s\n", files_array[i], files_array[i]);
      } else if (flags[4] && !flags[7] && files_count > 1) {
        printf("%s:%d\n", files_array[i], count_lines_ok_regex);
      } else if (flags[4] && ((flags[5] && flags[7]) || flags[5]) &&
                 PLATFORM_MAC && files_count == 1 && count_lines_ok_regex > 0) {
        printf("1\n");
        printf("%s\n", files_array[i]);
      } else if (flags[4] && ((flags[5] && flags[7]) || flags[5]) &&
                 PLATFORM_MAC && files_count == 1 &&
                 count_lines_ok_regex == 0) {
        printf("0\n");
      } else if (flags[4] && files_count == 1) {
        if (files_count > 1) printf("%s:", files_array[i]);
        printf("%d\n", count_lines_ok_regex);
      } else if (flags[4] && flags[7]) {
        printf("%d\n", count_lines_ok_regex);
      }
      if (flags[5] && !flags[4]) {
        if (count_lines_ok_regex > 0) printf("%s\n", files_array[i]);
      }
    } else if (flags[5] && count_lines_ok_regex_flag_4 > 0) {
      printf("%s\n", files_array[i]);
    } else if (flags[4]) {
      if (files_count > 1) printf("%s:", files_array[i]);
      printf("%d\n", count_lines_ok_regex_flag_4);
    }
    fclose(fp);
  }
}

/*
1 -e Шаблон
2 -i Игнорирует различия регистра.
3 -v Инвертирует смысл поиска соответствий.
4 -c Выводит только количество совпадающих строк.
5 -l Выводит только совпадающие файлы.
6 -n Предваряет каждую строку вывода номером строки из файла ввода.
7 -h Выводит совпадающие строки, не предваряя их именами файлов.
8 -s Подавляет сообщения об ошибках о несуществующих или нечитаемых файлах.
9 -f file Получает регулярные выражения из файла.
10 -o Печатает только совпадающие (непустые) части совпавшей строки.
 */

int regex(int *flags, char *string) {
  regex_t regex;
  int reg_result;
  int return_flag = 0;
  for (int i = 0; patterns_array[i]; i++) {
    if (i) regfree(&regex);
    if (flags[2])
      reg_result = regcomp(&regex, patterns_array[i], REG_EXTENDED | REG_ICASE);
    else {
      reg_result = regcomp(&regex, patterns_array[i], 0);
    }
    if (reg_result) {
      continue;
    }
    if (flags[4] && patterns_array[i][0] == '.' && string[0] == '\n') {
      continue;
    } else {
      reg_result = regexec(&regex, string, 0, NULL, 0);
      if (!reg_result) {
        return_flag = 1;
        break;
      }
    }
  }
  regfree(&regex);
  if (flags[3]) {
    if (return_flag)
      return_flag = 0;
    else
      return_flag = 1;
  }
  return return_flag;
}

int regex_o_flag(const int *flags, char *string, int count_lines_of_file,
                 int files_count, char *file_name) {
  regex_t regex;
  int reg_result;
  char *ps;
  regmatch_t pmatch[100];
  int int_regex_flag = 0;
  int count_ok_regex_flag_3 = 0;
  int count_lines_ok_regex_flag_4 = 0;
  int file_name_print = 0;
  int count_lines_of_file_print = 0;

  for (int i = 0; patterns_array[i]; i++) {
    if (i) regfree(&regex);
    if (flags[2])
      reg_result = regcomp(&regex, patterns_array[i], REG_EXTENDED | REG_ICASE);
    else {
      reg_result = regcomp(&regex, patterns_array[i], REG_EXTENDED);
    }
    if (reg_result) {
      continue;
    }
    ps = string;
    while (!(reg_result = regexec(&regex, ps, 1, pmatch, int_regex_flag))) {
      count_lines_ok_regex_flag_4++;
      if (flags[3] || flags[4] || flags[5]) {
        count_ok_regex_flag_3++;
        break;
      }
      if (files_count > 1 && !flags[7] && file_name_print == 0) {
        printf("%s:", file_name);
        file_name_print++;
      }
      if (flags[6] && count_lines_of_file_print == 0) {
        printf("%d:", count_lines_of_file);
        count_lines_of_file_print++;
      }
      if (!flags[4]) {
        for (long long index = pmatch->rm_so; index < pmatch->rm_eo; index++)
          printf("%c", ps[index]);
        printf("\n");
      }
      ps += pmatch[0].rm_eo;
    }
  }
  regfree(&regex);
  if (flags[3] && count_ok_regex_flag_3 == 0 && !flags[4] && !flags[5]) {
    if (files_count > 1 && !flags[7]) {
      printf("%s:", file_name);
    }
    if (flags[6]) printf("%d:", count_lines_of_file);
    printf("%s", string);
  }
  count_ok_regex_flag_3 = 0;

  return count_lines_ok_regex_flag_4;
}