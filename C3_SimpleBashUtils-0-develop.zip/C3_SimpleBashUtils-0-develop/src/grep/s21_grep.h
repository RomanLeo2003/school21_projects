#include <errno.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char **patterns_array = NULL;
char **files_array = NULL;

void parser_flags(int argc, char *argv[], int *flags);
void parser_patterns(int argc, char *argv[], const int *flags);
void add_pattern(char *pattern);
void add_file(char *file);
void parser_patterns_from_file(char *patterns_file);
void mystrcatone(char *dst, char src);
int regex(int *flags, char *string);
void printer(int *flags);
int regex_o_flag(const int *flags, char *string, int count_lines_of_file,
                 int files_count, char *file_name);
void clean_memeory();

int PLATFORM_MAC = 0;
int patterns_array_size = 100;
int file_array_size = 100;

int pattern_count = 0;
int file_count = 0;

#define BUFFSIZE 1024

#if defined(__APPLE__) && defined(__MACH__)
#define PLATFORM_MAC 1
#endif