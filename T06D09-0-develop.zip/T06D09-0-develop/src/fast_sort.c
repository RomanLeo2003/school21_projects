#include <stdio.h>
#define N 10

int input(int *a, int n);
void output(int *a, int n);
void heapsort(int *a, int n);
void heapify(int *a, int i);
void quick_sort(int *a, int n);
int RIGHT(int i);
int LEFT(int i);
void copys(int *a, int *arr, int n);
void swap(int *x, int *y);

int end;

int main() {
    int arr[N], copy[N];
    if (input(arr, N)) {
        copys(copy, arr, N);
        quick_sort(arr, N);
        output(arr, N);
        printf("\n");
        heapsort(copy, N);
        output(copy, N);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]))
            continue;
        else
            return 0;
    }
    return 1;
}

void swap(int *x, int *y) {
    int z;
    z = *x;
    *x = *y;
    *y = z;
}

int LEFT(int i) {
    return (2*i + 1);
}

int RIGHT(int i) {
    return (2*i + 2);
}

void heapify(int *a, int i) {
    int left = LEFT(i);
    int right = RIGHT(i);
    int largest = i;
    if (left < end && a[left] > a[i]) {
        largest = left;
    }
    if (right < end && a[right] > a[largest]) {
        largest = right;
    }
    if (largest != i) {
        swap(&a[i], &a[largest]);
        heapify(a, largest);
    }
}

void BuildHeap(int *a) {
    int i = (end - 2) / 2;
    while (i >= 0) {
        heapify(a, i--);
    }
}

void heapsort(int *a, int n) {
    end = n;
    BuildHeap(a);
    while (end != 1) {
        swap(&a[0], &a[end - 1]);
        end--;
        heapify(a, 0);
    }
}

void copys(int *a, int *arr, int n) {
    for (int i = 0; i < n; i++) {
        a[i] = arr[i];
    }
}

void quick_sort(int *a, int n) {
    int i = 0;
    int j = n - 1;
    int mid = a[n / 2];
    do {
        while (a[i] < mid)
            i++;
        while (a[j] > mid)
            j--;
        if (i <= j) {
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            i++;
            j--;
        }
    } while (i <= j);

    if (j > 0) {
        quick_sort(a, j + 1);
    }
    if (i < n) {
        quick_sort(&a[i], n - i);
    }
}

void output(int *a, int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}
