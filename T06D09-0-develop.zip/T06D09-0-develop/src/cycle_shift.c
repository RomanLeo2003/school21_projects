#include <stdio.h>
#define NMAX 10

int input(int *a, int *n, int *shift);
void cycle_shift(int *a, int *sh_a, int n, int shift);
void output(int *a, int n);

int main() {
    int arr[NMAX], shift_arr[NMAX], n, shift;
    if (input(arr, &n, &shift)) {
        cycle_shift(arr, shift_arr, n, shift);
        output(shift_arr, n);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int *n, int *shift) {
    int scan = scanf("%d", n);
    if (scan && *n > 0 && *n <= NMAX) {
        for (int i = 0; i < *n; i++) {
            if (scanf("%d", &a[i]))
                continue;
            else
                return 0;
        }
    } else {
        return 0;
    }
    int sc = scanf("%d", shift);
    if (sc) {
        return 1;
    }
    return 0;
}

void cycle_shift(int *a, int *sh_a, int n, int shift) {
    for (int i = 0; i < n; i++) {
        if (i + shift >= n)
            sh_a[i] = a[i + shift - n];
        else if (i + shift < 0)
            sh_a[i] = a[i + n + shift];
        else
            sh_a[i] = a[i + shift];
    }
}

void output(int *a, int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}
