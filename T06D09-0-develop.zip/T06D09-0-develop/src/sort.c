#include <stdio.h>
#define N 10

int input(int *a, int n);
void output(int *a, int n);
void quick_sort(int *a, int n);

int main() {
    int arr[N];
    if (input(arr, N)) {
        quick_sort(arr, N);
        output(arr, N);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]))
            continue;
        else
            return 0;
    }
    return 1;
}

void quick_sort(int *a, int n) {
    int i = 0;
    int j = n - 1;
    int mid = a[n / 2];
    do {
        while (a[i] < mid)
            i++;
        while (a[j] > mid)
            j--;
        if (i <= j) {
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            i++;
            j--;
        }
    } while (i <= j);

    if (j > 0) {
        quick_sort(a, j + 1);
    }
    if (i < n) {
        quick_sort(&a[i], n - i);
    }
}

void output(int *a, int n) {
    int i;
    for (i = 0; i < n - 1; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}

