#include <stdio.h>
#define NMAX 10

int input(int *buffer, int *length);
void output(int *a, int n, int sum);
int sum_numbers(int *buffer, int length);
int find_numbers(int* buffer, int length, int number, int* numbers);

int main() {
    int arr[NMAX], find[NMAX], n;
    if (input(arr, &n)) {
        if (n == 1 && arr[0] == 0) {
            printf("n/a");
        } else {
            int sum = sum_numbers(arr, n);
            int n_find = find_numbers(arr, n, sum, find);
            output(find, n_find, sum);
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *buffer, int *length) {
    int scan = scanf("%d", length);
    if (scan && *length > 0 && *length <= NMAX) {
        for (int i = 0; i < *length; i++) {
            if (scanf("%d", &buffer[i]))
                continue;
            else
                return 0;
        }
    } else {
        return 0;
    }
    return 1;
}

int sum_numbers(int *buffer, int length) {
int sum = 0;
for (int i = 0; i < length; i++) {
    if (buffer[i] % 2 == 0) {
        sum += buffer[i];
    }
}
return sum;
}

int find_numbers(int* buffer, int length, int number, int* numbers) {
    int j = 0;
    for (int i = 0; i < length; ++i) {
        if (buffer[i] != 0 && number % buffer[i] == 0) {
            numbers[j] = buffer[i];
            j++;
        }
    }
    return j;
}

void output(int *a, int n, int sum) {
    int i;
    printf("%d\n", sum);
    for (i = 0; i < n - 1; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}
