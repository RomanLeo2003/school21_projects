#include <stdio.h>

#define LEN 100

int input(int *a);
void output(int *a, int n);
void sum(int *buff1, int len1, int *buff2, int *result, int *result_length);
void sub(int *buff1, int len1, int *buff2, int *result, int *result_length);
void init(int *a, int len);
void shifting(int *arr, int *cur, int len1, int len2);

int main() {
    int num1[LEN], num2[LEN], len1, len2;
    len1 = input(num1);
    len2 = input(num2);
    if (len2 <= len1) {
        printf("1");
        int current[LEN];
        shifting(num2, current, len1, len2);
        int result[LEN], result_length;
        sum(num1, len1, num2, result, &result_length);
        output(result, result_length);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a) {
    int len = 0;
    char c;
    while (scanf("%d%c", &a[len], &c) == 2 && c != '\n') {
        len++;
        continue;
    }
    return len;
}

void shifting(int *arr, int *cur, int len1, int len2) {
    for (int i = 0; i <= len1; i++) {
        if (i < len2)
            cur[i] = 0;
        else
            cur[i] = arr[i - len2];
    }
}

void output(int *a, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("%d", a[i]);
}

void sum(int *buff1, int len1, int *buff2, int *result, int *result_length) {
    int mind = 0;
    for (int i = len1; i > 0; i++) {
        int summa = buff1[i] + buff2[i];
        if (summa < 10) {
            result[len1 - i] = summa + mind;
            mind = 0;
        } else {
            result[len1 - i] = summa % 10 + mind;
            mind = 1;
        }
    }
    *result_length = len1;
}
