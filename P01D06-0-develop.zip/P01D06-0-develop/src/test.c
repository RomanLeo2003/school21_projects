#include <stdio.h>
#include <stdlib.h>

#define length 80
#define height 25

int rocket(char c, int y1, int y2) {
    if (y1 == height - 3) {
        if (c == 'a')
            return y1 - 1;
        return y1;
    } else if (y1 == 2) {
        if (c == 'z')
            return y1 + 1;
        return y2;
    } else if (-y2 == height - 3) {
        if (c == 'k')
            return y2 + 1;
        return y1;
    } else if (-y2 == 2) {
        if (c == 'm')
            return y2 - 1;
        return y2;
    } else if (c == 'a' || c == 'A') {
        return y1 - 1;
    } else if (c == 'z' || c == 'Z') {
        return y1 + 1;
    } else if (c == 'k' || c =='K') {
        return y2 + 1;
    } else if (c == 'm' || c =='M') {
        return y2 - 1;
    } else {
        return y1;
    }
}

void congratulation(int score1, int score2) {
    if (score1 == 21) {
        printf("   ##      WW       WW    II     NN   NN      SSSSS    !!\n");
        printf("###       WW  W  WW     II     NNNN NN      SSS      !!\n");
        printf(" ##        WW W WW      II     NN NNNN       SS      !!\n");
        printf(" ##         WWWWW       II     NN   NN    SSSSS      !!\n");
    } else if (score2 == 21) {
        printf("  #####      WW       WW    II     NN   NN      SSSSS    !!\n");
        printf("  ###       WW  W  WW     II     NNNN NN      SSS      !!\n");
        printf("##           WW W WW      II     NN NNNN       SS      !!\n");
        printf("######        WWWWW       II     NN   NN    SSSSS      !!\n");
    }
}


void draw(int rocket1, int rocket2, int x, int y, int score1, int score2) {
    printf("\n");
    for (int i = 0; i <= height + 1; ++i) {
        for (int j = 0; j <= length; ++j) {
            if (i == rocket1 && j == 0)
                printf("%c", '|');
            else if (i == rocket1 + 1 && j == 0)
                printf("%c", '|');
            else if (i == rocket1 + 2 && j == 0)
                printf("%c", '|');
            else if (i == -rocket2 && j == length)
                printf("%c", '|');
            else if (i == -rocket2 + 1 && j == length)
                printf("%c", '|');
            else if (i == -rocket2 + 2 && j == length)
                printf("%c", '|');
            else if (i == height + 1 && j == length / 2 - 1)
                printf("%d %s %d", score1, "||", score2);
            else if (i == y && j == x)
                printf("%c", '*');
            else if (i == 0)
                printf("-");
            else if (i == height)
                printf("-");
            else
                printf("%c", ' ');
        }
        printf("%c", '\n');
    }
}


int main() {
    char button;
    int rocket1 = 11, rocket2 = -11, x = 1, y = 12;
    int vecX = 1, vecY = -1, score1 = 0, score2 = 0;
    while (1) {
        if (score1 == 21 || score2 == 21) {
            break;
        } else {
            system("stty -icanon");
            button = getc(stdin);
            printf("\n%d %d %d %d", x, y, rocket1, -rocket2);
            if (button == ' ') {
                draw(rocket1, rocket2, x, y, score1, score2);
            } else {
                int current_rocket = rocket(button, rocket1, rocket2);
                if (current_rocket > 0)
                    rocket1 = current_rocket;
                else
                    rocket2 = current_rocket;
            }
            if (vecX == 1 && vecY == -1) {
                x++;
                y++;
                if (y == height) {
                    vecY = 1;
                } else if (x == length - 1 && -rocket2 <= y
                           && y <= -rocket2 + 2) {
                    vecX = -1;
                } else if (x == length && !(-rocket2 <= y
                                            && y <= -rocket2 + 2)) {
                    rocket1 = 12;
                    rocket2 = -12;
                    x = 1;
                    y = 13;
                    vecX = 1;
                    vecY = -1;
                    score1++;
                }
            } else if (vecX == 1 && vecY == 1) {
                y--;
                x++;
                if (y == 0) {
                    vecY = -1;
                } else if (x == length - 1 && -rocket2 <= y
                           && y <= -rocket2 + 2) {
                    vecX = -1;
                } else if (x == length && !(-rocket2 <= y
                                            && y <= -rocket2 + 2)) {
                    rocket1 = 12;
                    rocket2 = -12;
                    x = 1;
                    y = 13;
                    vecX = 1;
                    vecY = -1;
                    score1++;
                }
            } else if (vecX == -1 && vecY == 1) {
                y--;
                x--;
                if (y == 0) {
                    vecY = -1;
                } else if (x == 1 && rocket1 <= y && y <= rocket1 + 2) {
                    vecX = 1;
                } else if (x == 0 && !(rocket1 <= y && y <= rocket1 + 2)) {
                    rocket1 = 12;
                    rocket2 = -12;
                    x = length;
                    y = 13;
                    vecX = -1;
                    vecY = -1;
                    score2++;
                }
            } else if (vecX == -1 && vecY == -1) {
                y++;
                x--;
                if (y == height) {
                    vecY = 1;
                } else if (x == 1 && rocket1 <= y && y <= rocket1 + 2) {
                    vecX = 1;
                } else if (x == 0 && !(rocket1 <= y && y <= rocket1 + 2)) {
                    rocket1 = 12;
                    rocket2 = -12;
                    x = length; y = 13;
                    vecX = -1;
                    vecY = -1;
                    score2++;
                }
            }
        }
    }
    congratulation(score1, score2);
    return 0;
}

