#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include "logger.h"

int input(char str[100]) {
    char c;
    int i = 0;
    scanf("%c", &c);
    scanf("%c", &c);
    while (c != '\n') {
        str[i] = c;
        i++;
        scanf("%c", &c);
    }
    return 1;
}

void encrypt(int n, char *p_in, char *p_out) {
    FILE *fp1, *fp2;
    fp1 = fopen(p_in, "r");
    fp2 = fopen(p_out, "a");
    int flag;
    char c;
    c = getc(fp1);
    while (!feof(fp1) && fp1) {
        flag = 0;
        if (c >= 'A' && c <= 'Z') {
            c = c + (n % 26);
            if (c > 'Z') c = 'A' + (c - 'Z') - 1;
            fputc(c, fp2);
            flag = 1;
        }
        if (c >= 'a' && c <= 'z') {
            c = c + (n % 26);
            if (c > 'z') c = 'a' + (c - 'z') - 1;
            fputc(c, fp2);
            flag = 1;
        }
        if (!flag) fputc(c, fp2);
        c = getc(fp1);
    }
    fclose(fp1);
    fclose(fp2);
}

void q_3() {
    DIR *dp;
    struct dirent *dirp;

    char path[] = "../src/ai_modules/";
    char name[200], name_cpy[200];
    FILE *f;

    dp = opendir("../src/ai_modules/");
    int shift;
    scanf("%d", &shift);
    while ((dirp = readdir(dp)) != NULL) {
        if (strstr(dirp->d_name, ".h") != NULL) {
            strcpy(name, path);
            strcat(name, dirp->d_name);
            f = fopen(name, "w");
            fclose(f);
        }
        if (strstr(dirp->d_name, ".c") != NULL) {
            strcpy(name, path);
            strcat(name, dirp->d_name);
            strcpy(name_cpy, name);
            strcat(name_cpy, "c");
            encrypt(shift, name, name_cpy);
            remove(name);
            rename(name_cpy, name);
        }
    }
    closedir(dp);
}

int main() {
    FILE *f;
    char filename[100], fstr[200];
#ifdef LOG
    FILE *log_file;
    char *log_file_name = "../src/log_file.txt";
    char str_deb1[300] = "Проверен на существование файл ";
    char str_eof1[300] = "Невозможно открыть файл ";
    char str_infin1[300] = "Введено сообщение в файл ";
    char str_inf1[300] = "Сообщение прочитано из файла ";
    char str_deb[300] = "Проверен на существование файл ";
    char str_eof[300] = "Невозможно открыть файл ";
    char str_infin[300] = "Введено сообщение в файл ";
    char str_inf[300] = "Сообщение прочитано из файла ";
    log_file = log_init(log_file_name);
    logcat(log_file, "Начало работы программы", 2);
    log_close(log_file);

#endif
    int but;
    while (1) {
        fflush(stdin);
        scanf("%d", &but);
        if (but == 1) {
            scanf("%s", filename);
            f = fopen(filename, "r");
            if (f && getc(f) != EOF) {
                fclose(f);
#ifdef LOG
                log_file = log_init(log_file_name);
                strcpy(str_deb, str_deb1);
                strcat(str_deb, filename);
                logcat(log_file, str_deb, 0);
                log_close(log_file);
#endif
                f = fopen(filename, "r");
                while (!feof(f)) {
                    if (fgets(fstr, 200, f))
                       printf("%s\n", fstr);
                }
#ifdef LOG
                log_file = log_init(log_file_name);
                strcpy(str_inf, str_inf1);
                strcat(str_inf, filename);
                logcat(log_file, str_inf, 2);
                log_close(log_file);
#endif
                fclose(f);
            } else {
#ifdef LOG
                log_file = log_init(log_file_name);
                strcpy(str_eof, str_eof1);
                strcat(str_eof, filename);
                logcat(log_file, str_eof, 4);
                log_close(log_file);
#endif
                printf("n/a\n");
                continue;
            }
        } else if (but == -1) {
#ifdef LOG
            log_file = log_init(log_file_name);
            logcat(log_file, "Завершение работы программы", 2);
            log_close(log_file);
#endif
            break;
        } else if (but == 2) {
            char to_file[100];
            input(to_file);
            if ((f = fopen(filename, "r"))) {
#ifdef LOG
                log_file = log_init(log_file_name);
                strcat(str_deb, filename);
                logcat(log_file, str_deb, 0);
                log_close(log_file);
#endif
                fclose(f);
                f = fopen(filename, "a");
#ifdef LOG
                log_file = log_init(log_file_name);
                strcpy(str_infin, str_infin1);
                strcat(str_infin, filename);
                logcat(log_file, str_infin, 2);
                log_close(log_file);
#endif
                fputs(to_file, f);
                fclose(f);
                f = fopen(filename, "r");
                while (!feof(f)) {
                    if (fgets(fstr, 200, f))
                       printf("%s\n", fstr);
                }
                fclose(f);
            } else {
#ifdef LOG
                log_file = log_init(log_file_name);
                strcpy(str_eof, str_eof1);
                strcat(str_eof, filename);
                logcat(log_file, str_eof, 4);
                log_close(log_file);
#endif
                printf("n/a\n");
                continue;
            }
        } else if (but == 3) {
            q_3();
        } else {
#ifdef LOG
                log_file = log_init(log_file_name);
                logcat(log_file, "Такой команды нет в меню", 4);
                log_close(log_file);
#endif
            printf("n/a\n");
            continue;
        }
    }
    return 0;
}
