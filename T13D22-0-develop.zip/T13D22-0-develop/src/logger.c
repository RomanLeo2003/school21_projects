#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "logger.h"
#include "log_levels.h"

FILE* log_init(char *filename) {
    FILE *f_l = fopen(filename, "a");
    return f_l;
}

int logcat(FILE* log_file, char *message, enum log_level level) {
    const time_t t = time(NULL);
    struct tm *u = localtime(&t);
    switch (level) {
        case 0:
            fprintf(log_file, "DEBUG");
            break;
        case 1:
            fprintf(log_file, "TRACE");
            break;
        case 2:
            fprintf(log_file, "INFO");
            break;
        case 3:
            fprintf(log_file, "WARNING");
            break;
        case 4:
            fprintf(log_file, "ERROR");
            break;
    }
    fprintf(log_file, " %02d:%02d:%02d ", u->tm_hour, u->tm_min, u->tm_sec);
    fprintf(log_file, "%s\n", message);
    return 1;
}

int log_close(FILE* log_file) {
    return fclose(log_file);
}
