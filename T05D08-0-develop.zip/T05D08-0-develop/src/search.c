#include <stdio.h>
#include <math.h>
#define NMAX 30

int input(int *a, int *n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);
int is_even(int x);
double std(int *a, int n);
int search(int *a, int n);

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("%d", search(data, n));
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int *n) {
    int scan = scanf("%d", n);
    if (scan && *n > 0 && *n <= NMAX) {
        for (int i = 0; i < *n; i++) {
            if (scanf("%d", &a[i]))
                continue;
            else
                return 0;
        }
    } else {
        return 0;
    }
    return 1;
}

int is_even(int x) {
    return (x % 2 == 0);
}

double mean(int *a, int n) {
    double sum = 0;
    for (int i = 0; i < n; ++i)
        sum += a[i];
    return sum / n;
}

double variance(int *a, int n) {
    int a_squared[NMAX];
    for (int i = 0; i < n; i++)
        a_squared[i] = a[i] * a[i];
    return (mean(a_squared, n)  - mean(a, n) * mean(a, n));
}

double std(int *a, int n) {
    return pow(variance(a, n), 0.5);
}

int search(int *a, int n) {
    for (int i = 0; i < n; ++i) {
        if (is_even(a[i]) && a[i] >= mean(a, n)
            && a[i] != 0
            && a[i] <= (mean(a, n) + 3 * std(a, n)))
            return a[i];
    }
    return 0;
}
