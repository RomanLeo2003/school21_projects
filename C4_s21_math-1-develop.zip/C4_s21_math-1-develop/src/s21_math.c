#include "s21_math.h"

int s21_abs(int x) {
  if (x > INT_MIN && x < 0)  // если мы передаем число = min_int(-2147483648),
                             // то модуль от него не берется
    x = -x;
  return x;
}

long double s21_ceil(double x) {
  long double res;
  long long int num;
  if (x != x || x == S21_INF_POS || x == S21_INF_NEG) {
    res = x;
  } else {
    num = (long long int)x;
    if (x > 0 && (x - num))  // если число положительное и остаток есть
      num += 1;
    res = num;
    if (res == 0 && x < 0) res = -res;
  }
  return res;
}

long double s21_floor(double x) {
  long double res;
  long long int num;
  if (x != x || x == S21_INF_POS || x == S21_INF_NEG) {
    res = x;
  } else {
    num = (long long int)x;
    if (x < 0 && (x - num))  // если число отрицательное и остаток есть
      num -= 1;
    res = num;
  }
  return res;
}

long double s21_fabs(double x) {
  if (x < 0) x = -x;
  return (long double)x;
}

long double s21_sqrt(double x) {
  long double chast = 0, num = 0;
  if (x != x || x == S21_INF_NEG || x < 0) {
    num = S21_NAN;
  } else if (x == S21_INF_POS) {
    num = x;
  } else {
    for (int i = 0; (num + 1) * (num + 1) <= x;
         i++) {  // определение целой части результата
      num = (long double)i;
    }
    for (int j = 0; j <= 10; j++) {  // задаем точность 10 знаков после запятой
      long double del = 1;
      for (int i = 0; i <= j; i++)
        del /= 10;  // определяем разряд (десятые, сотые, тысячные и т.д.)
      for (int i = 0; (num + (i + 1) * del) * (num + (i + 1) * del) <= x; i++) {
        chast = i * del;
      }
      num += chast;
    }
  }
  return num;
}

long double s21_atan(double x) {  // с помощью ряда Тейлора
  long double result = 0;
  if (x == S21_INF_POS) {
    result = S21_PI / 2;
  } else if (x == S21_INF_NEG) {
    result = -S21_PI / 2;
  } else if (x != x) {
    result = x;
  } else if (x > -1 && x < 1) {
    result = x;
    for (int i = 1; i < 7000; i++) {
      result += s21_pow_int(-1, i) * s21_pow_int(x, 1 + 2 * i) / (1 + 2 * i);
    }
  } else if (x == 1) {
    result = 0.785398163;
  } else if (x == -1) {
    result = -0.785398163;
  } else {
    result = 1. / x;
    for (int i = 1; i < 7000; i++)
      result += s21_pow_int(-1, i) * s21_pow_int(x, -1 - 2 * i) / (1 + 2 * i);
    result = (S21_PI * s21_fabs(x) / (2 * x)) - result;
  }
  return result;
}

long double s21_asin(double x) {
  long double result = S21_NAN;
  if (x > -1 && x < 1) {
    result = s21_atan(x / s21_sqrt(1 - x * x));
  } else if (x == 1) {
    result = 1.57079633;
  } else if (x == -1) {
    result = -1.57079633;
  }
  return result;
}

long double s21_acos(double x) {
  long double result = S21_NAN;
  if (x >= 0 && x < 1) {
    result = s21_atan(s21_sqrt(1 - x * x) / x);
  } else if (x > -1 && x < 0) {
    result = S21_PI + s21_atan(s21_sqrt(1 - x * x) / x);
  } else if (x == -1) {
    result = 3.14159265;
  } else if (x == 1) {
    result = 0;
  }
  return result;
}

long double s21_sin(double x) {
  long double result = 0;
  x = s21_fmod(x, 2 * S21_PI);
  for (int i = 0; i < 15; i++)
    result += s21_pow_int(-1, i) * s21_pow_int(x, 1 + 2 * i) * 1. /
              s21_fuctorial(1 + 2 * i);
  return result;
}

long double s21_cos(double x) {
  long double result = 0;
  x = s21_fmod(x, 2 * S21_PI);
  for (int i = 0; i < 15; i++)
    result +=
        s21_pow_int(-1, i) * s21_pow_int(x, 2 * i) * 1. / s21_fuctorial(2 * i);
  return result;
}

long double s21_tan(double x) {
  x = s21_fmod(x, S21_PI);
  return s21_sin(x) / s21_cos(x);
}

long double s21_exp(double x) {  // x = k*ln(2) + r , 2^k*e^r
  long double result = 0;
  long double k =
      (long long int)(x / S21_LN2);  // выделяем количество логарифмов в числе
  long double r = x - k * S21_LN2;  // находим остаток
  if (x != S21_INF_NEG) {
    for (int i = 0; i < 128; i++) {
      result += s21_pow_int(r, i) /
                s21_fuctorial(i);  // е на р раскладываем в ряд Тейлора
    }
    result *= s21_pow_int(2, k);
  }
  return result;
}

long double s21_log(double x) {  //метод Галея
  long double result = 0, compare = 0;
  if (x == S21_INF_POS) {
    result = x;
  } else if (x == 0) {
    result = S21_INF_NEG;
  } else if (x < 0) {
    result = S21_NAN;
  } else {
    int e_repeat = 0;
    for (; x >= S21_E; e_repeat++) x /= S21_E;
    for (int i = 0; i < 100; i++) {
      compare = result;
      result = compare + 2 * (x - s21_exp(compare)) / (x + s21_exp(compare));
    }
    result += e_repeat;
  }
  return result;
}

long double s21_fmod(double x, double y) {
  long double res = 0;
  if (y == 0 || (x == S21_INF_POS && y == S21_INF_POS) ||
      (x == S21_INF_NEG && y == S21_INF_NEG) || x == S21_INF_POS ||
      x == S21_INF_NEG) {
    res = S21_NAN;
  } else if (y == S21_INF_POS || y == S21_INF_NEG) {
    res = x;
  } else {
    long long int n = x / y;
    res = (long double)x - n * (long double)y;
  }
  return res;
}

long double s21_pow(double base, double exp) {  // e^(exp * ln(base))
  long double res = 0;
  if (!exp) {
    res = 1;
  } else if (base == S21_INF_NEG && exp == S21_INF_POS) {
    res = S21_INF_POS;
  } else if (base == S21_INF_NEG && exp == S21_INF_NEG) {
    res = 0;
  } else if (base < 0) {
    if (exp == (long long int)exp) {
      base = -base;
      res = s21_exp(exp * s21_log(base));
      if (s21_fmod(exp, 2)) res = -res;
    } else {
      res = S21_NAN;
    }
  } else {
    res = s21_exp(exp * s21_log(base));
  }
  return res;
}

long double s21_fuctorial(long long int x) {
  long double res = 1, one = 1, na = S21_INF_POS;
  if (x == 1 || x == 0)
    res = one;
  else if (x < 0)
    res = na;
  else
    res = x * s21_fuctorial(x - 1);
  return res;
}

long double s21_pow_int(double base, long long int exp) {
  long double result = 1;
  if (exp > 0)
    for (long long int i = 0; i < exp; i++) result *= base;
  else
    for (long long int i = 0; i < -exp; i++) result /= base;
  return result;
}
