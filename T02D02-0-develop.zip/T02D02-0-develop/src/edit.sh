#!/bin/bash
read -p "file: " file
if [ -f ~/$file ]; then
    read -p "old_string: " old
    read -p "new_string: " new
    sed -i '.bak' "s/$old/$new/gi" ~/$file
    shasum=$(shasum -a 256 ~/$file | awk ' { print $1 } ')
    bytes=$(stat -f "%z" ~/$file)
    data=$(date +"%Y-%d-%m %H:%M")
    echo ${file#*/} - $bytes - $data - $shasum - sha256 >> ./files.log
else
    echo Введенный файл не существует, запустите программу заново
fi
