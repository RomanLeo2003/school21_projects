#include "sort.h"

void sort(double *a, int n) {
    int i = 0;
    int j = n - 1;
    int mid = a[n / 2];
    do {
        while (a[i] < mid)
            i++;
        while (a[j] > mid)
            j--;
        if (i <= j) {
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            i++;
            j--;
        }
    } while (i <= j);

    if (j > 0) {
        sort(a, j + 1);
    }
    if (i < n) {
        sort(&a[i], n - i);
    }
}

