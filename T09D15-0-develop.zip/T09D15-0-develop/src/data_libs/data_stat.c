#include "data_stat.h"
#include <math.h>
#include <stdlib.h>

double max(double *data, int n) {
    double maxi = data[0];
    for (int i = 0; i < n - 1; i++) {
        if (data[i] < data[i + 1])
            maxi = data[i + 1];
    }
    return maxi;
}

double min(double *data, int n) {
    double mini = data[0];
    for (int i = 0; i < n - 1; i++) {
        if (data[i] > data[i + 1])
            mini = data[i + 1];
    }
    return mini;
}

double mean(double *data, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++)
        sum += data[i];
    return sum / n;
}

double variance(double *data, int n) {
    double *copy = (double*)malloc(n * sizeof(double));
    for (int i = 0; i < n; i++)
        copy[i] = data[i] * data[i];
    double var = mean(copy, n) - (mean(data, n) * mean(data, n));
    free(copy);
    return var;
}

