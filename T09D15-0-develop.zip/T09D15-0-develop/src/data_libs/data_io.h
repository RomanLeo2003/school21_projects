#ifndef SRC_DATA_LIBS_DATA_IO_H_
#define SRC_DATA_LIBS_DATA_IO_H_

int input(double *data, int n);
void output(double *data, int n);

#endif  // SRC_DATA_LIBS_DATA_IO_H_
