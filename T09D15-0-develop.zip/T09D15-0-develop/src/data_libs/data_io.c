#include <stdio.h>

#include "data_io.h"

int input(double *data, int n) {
    int check = 1;
    for (int i = 0; i < n; i++) {
        if (scanf("%lf", &data[i])) {
            check = 1;
        } else {
            check = 0;
            break;
        }
    }
    return check;
}

void output(double *data, int n) {
    int i;
    for (i = 0; i < n - 1; i++)
        printf("%.2lf ", data[i]);
    printf("%.2lf", data[i]);
}
