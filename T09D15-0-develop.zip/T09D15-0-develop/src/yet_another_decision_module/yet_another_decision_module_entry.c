#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "decision.h"
#include <stdlib.h>
#include <stdio.h>

int main() {
    double *data;
    int n;
    if (scanf("%d", &n)) {
        data = (double*)malloc(n * sizeof(double));
        if (input(data, n) && n > 0) {
            if (make_decision(data, n))
                printf("YES");
            else
                printf("NO");
        } else {
            printf("n/a");
        }
        free(data);
    } else {
        printf("n/a");
    }
    return 0;
}
